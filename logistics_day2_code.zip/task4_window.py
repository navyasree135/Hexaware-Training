"""
Task 4 - busiest 4-hour window in a day of hourly parcel counts.

Sliding window: add the new hour, drop the hour that fell out. The window
never moves back, so the whole day is one pass.
"""
import random
import time

WINDOW = 4


def best_window(counts, k=WINDOW):
    """Returns (start_hour, average). If two windows tie, the earlier one wins.
    Time O(n), extra space O(1)."""
    if k <= 0:
        raise ValueError("window size must be positive")
    if len(counts) < k:
        raise ValueError(f"need at least {k} hours of data, got {len(counts)}")
    total = sum(counts[:k])
    best_total, best_start = total, 0
    for end in range(k, len(counts)):
        total += counts[end] - counts[end - k]
        if total > best_total:
            best_total, best_start = total, end - k + 1
    return best_start, best_total / k


def best_window_bruteforce(counts, k=WINDOW):
    """Re-add k numbers for every start position. O(n * k)."""
    best_total, best_start = None, 0
    for s in range(len(counts) - k + 1):
        t = sum(counts[s:s + k])
        if best_total is None or t > best_total:
            best_total, best_start = t, s
    return best_start, best_total / k


def hourly_counts(seed=5):
    """24 made-up hourly parcel counts: quiet at night, a morning pickup rush
    and a bigger evening delivery rush."""
    rng = random.Random(seed)
    base = [60, 45, 40, 35, 50, 120, 310, 540, 720, 810, 760, 690,
            640, 600, 580, 620, 760, 940, 1010, 880, 640, 420, 240, 120]
    return [max(0, b + rng.randint(-40, 40)) for b in base]


def main():
    counts = hourly_counts()
    print("Hourly parcel counts (hour = start of the hour)")
    print(f"  total for the day: {sum(counts)} parcels")

    start, avg = best_window(counts)
    print(f"\nBusiest {WINDOW}-hour window: {start:02d}:00 to {start + WINDOW:02d}:00")
    print(f"  parcels in window: {sum(counts[start:start + WINDOW])}")
    print(f"  average per hour : {avg:.1f}")

    print("\nAverage of every possible window  (* = the winner)")
    for s in range(len(counts) - WINDOW + 1):
        a = sum(counts[s:s + WINDOW]) / WINDOW
        print(f"  {s:02d}:00-{s + WINDOW:02d}:00  {a:7.1f} {'*' if s == start else ''}")

    print("\nBrute force agrees:", best_window_bruteforce(counts) == (start, avg))

    # speed on a long list (a year of hourly data)
    rng = random.Random(1)
    big = [rng.randint(0, 1000) for _ in range(24 * 365 * 5)]
    t0 = time.perf_counter(); r1 = best_window(big, 24 * 7); t1 = time.perf_counter() - t0
    t0 = time.perf_counter(); r2 = best_window_bruteforce(big, 24 * 7); t2 = time.perf_counter() - t0
    print(f"\nSpeed on {len(big)} hourly readings with a 1-week (168 h) window")
    print(f"  sliding window {t1*1000:.1f} ms,  brute force {t2*1000:.1f} ms  "
          f"(same answer: {r1 == r2}, about {t2/t1:.0f}x slower)")

    print("\nEdge cases")
    print("  exactly 4 hours       ->", best_window([10, 20, 30, 40]))
    print("  all hours equal       ->", best_window([5] * 10))
    print("  tie (first one wins)  ->", best_window([9, 1, 1, 1, 1, 9, 1, 1, 1, 1, 1]))
    for bad in ([], [1, 2, 3]):
        try:
            best_window(bad)
        except ValueError as e:
            print(f"  {str(bad):<21} -> error: {e}")


if __name__ == "__main__":
    main()
