"""Draws the three figures used in the report. Needs matplotlib."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import task1_bst, task3_routes, task4_window

BLUE, ORANGE, GREY = "#2F5D8C", "#E08A2E", "#8A8F98"


# ---- Figure 1: the two trees -------------------------------------------
def positions(node, depth=0, counter=None, pos=None):
    """x = position in the inorder list, y = depth. Nothing overlaps this way."""
    if counter is None:
        counter, pos = [0], {}
    if node:
        positions(node.left, depth + 1, counter, pos)
        pos[node.code] = (counter[0], -depth)
        counter[0] += 1
        positions(node.right, depth + 1, counter, pos)
    return pos


def draw_tree(ax, tree, title):
    pos = positions(tree.root)

    def edges(node):
        for child in (node.left, node.right):
            if child:
                ax.plot([pos[node.code][0], pos[child.code][0]],
                        [pos[node.code][1], pos[child.code][1]], color=GREY, lw=1, zorder=1)
                edges(child)
    edges(tree.root)
    for code, (x, y) in pos.items():
        ax.scatter([x], [y], s=620, color=BLUE, zorder=2)
        ax.text(x, y, code, ha="center", va="center", color="white", fontsize=7.5, zorder=3)
    ax.set_title(title, fontsize=10)
    ax.axis("off")
    ax.set_ylim(min(p[1] for p in pos.values()) - 0.6, 0.6)
    xs = [p[0] for p in pos.values()]
    ax.set_xlim(min(xs) - 1, max(xs) + 1)


def fig_trees():
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [1, 1.1]})
    t1 = task1_bst.build(task1_bst.OPENING_ORDER)
    t2 = task1_bst.build(sorted(task1_bst.OPENING_ORDER))
    draw_tree(axes[0], t1, f"Opening order (height {t1.height()})")
    draw_tree(axes[1], t2, f"Alphabetical order (height {t2.height()})")
    fig.tight_layout()
    fig.savefig("fig1_trees.png", dpi=170)
    plt.close(fig)


# ---- Figure 2: the hub network -----------------------------------------
# rough map positions (longitude, latitude) so it looks like India
XY = {"NAG": (79.1, 21.1), "DEL": (79.0, 29.0), "JAI": (73.6, 26.4), "AMD": (72.6, 23.0),
      "BOM": (72.9, 19.1), "HYD": (78.5, 17.4), "BLR": (77.6, 13.0), "MAA": (80.3, 13.1),
      "CCU": (88.4, 22.6), "GAU": (91.7, 26.1)}


def fig_network():
    g = task3_routes.build_graph(task3_routes.HUBS, task3_routes.ROUTES)
    fig, ax = plt.subplots(figsize=(7.2, 5.6))
    for a, b in task3_routes.ROUTES:
        ax.plot([XY[a][0], XY[b][0]], [XY[a][1], XY[b][1]], color=GREY, lw=1.4, zorder=1)
    path = task3_routes.bfs_shortest(g, "JAI", "MAA")
    for a, b in zip(path, path[1:]):
        ax.plot([XY[a][0], XY[b][0]], [XY[a][1], XY[b][1]], color=ORANGE, lw=3.2, zorder=2)
    for h, (x, y) in XY.items():
        colour = ORANGE if h == task3_routes.CENTRAL_DEPOT else (GREY if not g[h] else BLUE)
        ax.scatter([x], [y], s=900, color=colour, zorder=3)
        ax.text(x, y, h, ha="center", va="center", color="white", fontsize=8.5, zorder=4)
    ax.text(91.7, 24.4, "no routes yet", ha="center", fontsize=8, color=GREY)
    ax.set_title("Hub network: orange line = JAI to MAA by BFS (3 hops); orange hub = central depot",
                 fontsize=9)
    ax.axis("off")
    ax.set_xlim(70, 94.5)
    ax.set_ylim(11.5, 30.5)
    fig.tight_layout()
    fig.savefig("fig2_network.png", dpi=170)
    plt.close(fig)


# ---- Figure 3: hourly parcels ------------------------------------------
def fig_hours():
    counts = task4_window.hourly_counts()
    start, avg = task4_window.best_window(counts)
    fig, ax = plt.subplots(figsize=(8.2, 3.5))
    colours = [ORANGE if start <= h < start + task4_window.WINDOW else BLUE for h in range(24)]
    ax.bar(range(24), counts, color=colours)
    ax.axhline(avg, color=ORANGE, ls="--", lw=1)
    ax.text(0.3, avg + 25, f"best 4-hour average = {avg:.1f}", color=ORANGE, fontsize=8)
    ax.set_xticks(range(24))
    ax.set_xticklabels([f"{h:02d}" for h in range(24)], fontsize=7)
    ax.set_xlabel("hour of day (start of hour)")
    ax.set_ylabel("parcels")
    ax.set_title(f"Parcels per hour; busiest 4-hour window is {start:02d}:00 to "
                 f"{start + task4_window.WINDOW:02d}:00", fontsize=9)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig("fig3_hours.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig_trees()
    fig_network()
    fig_hours()
    print("figures saved")
