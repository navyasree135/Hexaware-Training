"""
Task 3 - the hub network as a graph (adjacency list).

BFS finds the route with the fewest hops between two hubs.
DFS lists every hub that can be reached from the central depot.
Direct routes are two-way, so every edge is stored in both directions.
"""
from collections import deque

CENTRAL_DEPOT = "NAG"

# the 10 hubs. GAU (Guwahati) is a new hub that has no direct route yet.
HUBS = ["NAG", "DEL", "BOM", "MAA", "BLR", "HYD", "CCU", "AMD", "GAU", "JAI"]

# direct routes between hubs (made-up network)
ROUTES = [
    ("NAG", "DEL"), ("NAG", "BOM"), ("NAG", "HYD"), ("NAG", "CCU"),
    ("DEL", "JAI"), ("DEL", "CCU"),
    ("JAI", "AMD"), ("AMD", "BOM"),
    ("HYD", "BLR"), ("BLR", "MAA"), ("MAA", "CCU"),
]


def build_graph(hubs, routes):
    g = {h: [] for h in hubs}      # start every hub with an empty list so GAU shows up
    for a, b in routes:
        g[a].append(b)
        g[b].append(a)
    for hub in g:
        g[hub].sort()          # same visiting order on every run
    return g


def bfs_shortest(graph, start, goal):
    """Fewest-hops route. Returns the list of hubs, or None if no route.
    Time O(V + E), space O(V)."""
    for h in (start, goal):
        if h not in graph:
            raise ValueError(f"unknown hub: {h}")
    if start == goal:
        return [start]
    parent = {start: None}
    queue = deque([start])
    while queue:
        hub = queue.popleft()
        for nxt in graph[hub]:
            if nxt not in parent:
                parent[nxt] = hub
                if nxt == goal:                      # walk back to the start
                    path = [goal]
                    while parent[path[-1]] is not None:
                        path.append(parent[path[-1]])
                    return path[::-1]
                queue.append(nxt)
    return None


def dfs_reachable(graph, start):
    """Every hub reachable from start, in the order DFS meets them.
    Time O(V + E), space O(V)."""
    order = []
    visited = set()

    def visit(hub):
        visited.add(hub)
        order.append(hub)
        for nxt in graph[hub]:
            if nxt not in visited:
                visit(nxt)
    visit(start)
    return order


def main():
    g = build_graph(HUBS, ROUTES)
    print(f"Network: {len(g)} hubs, {len(ROUTES)} direct routes, central depot = {CENTRAL_DEPOT}")
    print("\nAdjacency list")
    for hub in sorted(g):
        print(f"  {hub}: {', '.join(g[hub]) if g[hub] else '(no direct routes)'}")

    print("\nFewest hops (BFS)")
    for a, b in [("JAI", "MAA"), ("AMD", "CCU"), ("BLR", "JAI"),
                 ("NAG", "NAG"), ("JAI", "GAU")]:
        path = bfs_shortest(g, a, b)
        if path is None:
            print(f"  {a} -> {b}: no route")
        else:
            print(f"  {a} -> {b}: {' > '.join(path)}   ({len(path) - 1} hop(s))")
    try:
        bfs_shortest(g, "JAI", "XYZ")
    except ValueError as e:
        print("  JAI -> XYZ: error,", e)

    print(f"\nReachable from {CENTRAL_DEPOT} (DFS)")
    order = dfs_reachable(g, CENTRAL_DEPOT)
    print("  visit order:", " > ".join(order))
    print(f"  {len(order)} of {len(g)} hubs reachable")
    missing = sorted(set(g) - set(order))
    print("  not reachable:", ", ".join(missing) if missing else "none")


if __name__ == "__main__":
    main()
