"""
Task 1 - BST of hub codes.

Insert and search, plus the height of the tree for a given insertion order.
Codes are compared in upper case so "maa" and "MAA" are the same hub.
"""


class Node:
    def __init__(self, code):
        self.code = code
        self.left = None
        self.right = None


class HubBST:
    def __init__(self):
        self.root = None
        self.size = 0

    def insert(self, code):
        """Add a hub code. Returns False if it was already in the tree.
        Time: O(h) where h is the height of the tree."""
        code = code.upper()
        new = Node(code)
        if self.root is None:
            self.root = new
            self.size = 1
            return True
        cur = self.root
        while True:
            if code == cur.code:
                return False              # duplicate, ignore it
            if code < cur.code:
                if cur.left is None:
                    cur.left = new
                    break
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = new
                    break
                cur = cur.right
        self.size += 1
        return True

    def search(self, code):
        """Returns (found, path). path = the hubs we looked at on the way down,
        so len(path) is the number of steps the search took."""
        code = code.upper()
        path = []
        cur = self.root
        while cur is not None:
            path.append(cur.code)
            if code == cur.code:
                return True, path
            cur = cur.left if code < cur.code else cur.right
        return False, path

    def height(self):
        """Number of levels. A tree with only a root has height 1."""
        def h(node):
            return 0 if node is None else 1 + max(h(node.left), h(node.right))
        return h(self.root)

    def inorder(self):
        out = []

        def walk(node):
            if node:
                walk(node.left)
                out.append(node.code)
                walk(node.right)
        walk(self.root)
        return out

    def draw(self):
        """Sideways picture: root on the left, right children on top."""
        lines = []

        def walk(node, depth):
            if node:
                walk(node.right, depth + 1)
                lines.append("    " * depth + node.code)
                walk(node.left, depth + 1)
        walk(self.root, 0)
        return lines


def build(order):
    t = HubBST()
    for c in order:
        t.insert(c)
    return t


def balanced_order(sorted_codes):
    """Middle element first, then the middle of each half, and so on.
    Inserting in this order gives the shortest tree possible."""
    if not sorted_codes:
        return []
    mid = len(sorted_codes) // 2
    return ([sorted_codes[mid]] + balanced_order(sorted_codes[:mid])
            + balanced_order(sorted_codes[mid + 1:]))


def avg_search_steps(tree, codes):
    return sum(len(tree.search(c)[1]) for c in codes) / len(codes)


# the 10 hubs, in the order the company opened them (this is the "given" order)
OPENING_ORDER = ["NAG", "DEL", "BOM", "MAA", "BLR", "HYD", "CCU", "AMD", "GAU", "JAI"]


def main():
    tree = build(OPENING_ORDER)
    print("Insertion order:", ", ".join(OPENING_ORDER))
    print(f"Hubs stored: {tree.size}, height = {tree.height()}")
    print("Insert 'maa' again ->", tree.insert("maa"), "(duplicate ignored)")

    print("\nTree (sideways, root on the left):")
    for line in tree.draw():
        print("   " + line)
    print("\nInorder:", ", ".join(tree.inorder()))

    print("\nSearching")
    for code in ["GAU", "BLR", "JAI", "GOI"]:
        found, path = tree.search(code)
        verdict = "found    " if found else "NOT found"
        print(f"  {code}  {verdict} after {len(path)} step(s): {' > '.join(path)}")

    # now the same 10 hubs in three different orders
    alpha = sorted(OPENING_ORDER)
    orders = [
        ("opening order (given)", OPENING_ORDER),
        ("alphabetical (sorted)", alpha),
        ("reverse alphabetical", alpha[::-1]),
        ("middle-first", balanced_order(alpha)),
    ]
    print("\nSame 10 hubs, different insertion order")
    print(f"  {'order':<24}{'height':>7}{'avg steps to search':>22}")
    for name, order in orders:
        t = build(order)
        print(f"  {name:<24}{t.height():>7}{avg_search_steps(t, OPENING_ORDER):>22.1f}")
    print("  (the inorder list is the same every time:",
          all(build(o).inorder() == tree.inorder() for _, o in orders), ")")

    sorted_tree = build(alpha)
    print("\nSorted insertion drawn out:")
    for line in sorted_tree.draw():
        print("   " + line)


if __name__ == "__main__":
    main()
