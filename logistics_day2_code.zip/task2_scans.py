"""
Task 2 - parcel tracking numbers in a hash map, and a check for parcels that
were scanned twice at the same hub.

Python's dict is a hash map, so I use it directly here.
"""
import random
import time


class ParcelBook:
    """tracking number -> list of (hub, time) scans."""

    def __init__(self):
        self.scans = {}

    def add_scan(self, tracking, hub, when):
        self.scans.setdefault(tracking, []).append((hub, when))

    def lookup(self, tracking):
        """Average O(1) - hash the tracking number, jump to its slot."""
        return self.scans.get(tracking)

    def __len__(self):
        return len(self.scans)


def find_double_scans(scan_list):
    """One pass over the scans. The key is (tracking, hub); the value is the
    list of times it was scanned there. Anything with 2 or more times is
    reported. Time O(n), extra space O(n)."""
    seen = {}
    for tracking, hub, when in scan_list:
        seen.setdefault((tracking, hub), []).append(when)
    return [(t, h, times) for (t, h), times in seen.items() if len(times) >= 2]


def find_double_scans_bruteforce(scan_list):
    """Compare every scan with every other scan. O(n^2). Only here to check
    that the hash map version gives the same answer."""
    found = {}
    n = len(scan_list)
    for i in range(n):
        for j in range(i + 1, n):
            a, b = scan_list[i], scan_list[j]
            if a[0] == b[0] and a[1] == b[1]:
                found.setdefault((a[0], a[1]), set()).update([a[2], b[2]])
    return found


SMALL_SCANS = [
    # tracking, hub, time
    ("TRK1001", "DEL", "08:05"),
    ("TRK1001", "NAG", "14:20"),
    ("TRK1001", "NAG", "14:26"),      # double scan at NAG, 6 minutes apart
    ("TRK1002", "BOM", "09:10"),
    ("TRK1002", "NAG", "16:40"),
    ("TRK1002", "HYD", "21:05"),      # fine, three different hubs
    ("TRK1003", "CCU", "10:00"),
    ("TRK1003", "CCU", "10:02"),
    ("TRK1003", "CCU", "10:03"),      # three scans at CCU
    ("TRK1004", "MAA", "11:30"),
    ("TRK1005", "BLR", "07:30"),
    ("TRK1005", "HYD", "12:00"),
    ("TRK1005", "BLR", "18:45"),      # went away and came back to BLR
]

HUBS = ["NAG", "DEL", "BOM", "MAA", "BLR", "HYD", "CCU", "AMD", "PNQ", "JAI"]


def make_scans(n_parcels, seed=3):
    """Each parcel gets 2-4 scans at different hubs. About 1 parcel in 50
    gets an extra repeat scan at a hub it already visited."""
    rng = random.Random(seed)
    scans = []
    injected = set()
    for p in range(n_parcels):
        trk = f"TRK{40000000 + p}"
        route = rng.sample(HUBS, rng.randint(2, 4))
        for k, hub in enumerate(route):
            scans.append((trk, hub, f"{6 + 3 * k:02d}:{rng.randint(0, 59):02d}"))
        if rng.random() < 0.02:
            hub = rng.choice(route)
            scans.append((trk, hub, "23:59"))
            injected.add((trk, hub))
    rng.shuffle(scans)
    return scans, injected


def main():
    book = ParcelBook()
    for t, h, w in SMALL_SCANS:
        book.add_scan(t, h, w)

    print(f"{len(SMALL_SCANS)} scans loaded for {len(book)} parcels")
    print("\nLookups")
    for trk in ["TRK1002", "TRK1004", "TRK9999"]:
        print(f"  {trk}: {book.lookup(trk)}")

    print("\nParcels scanned more than once at the same hub")
    dups = find_double_scans(SMALL_SCANS)
    print(f"  {'tracking':<10}{'hub':<6}{'times':<7}scan times")
    for t, h, times in dups:
        print(f"  {t:<10}{h:<6}{len(times):<7}{', '.join(times)}")

    # bigger test: generated data, checked against brute force
    scans, injected = make_scans(1500)
    fast = {(t, h) for t, h, _ in find_double_scans(scans)}
    slow = set(find_double_scans_bruteforce(scans))
    print(f"\nGenerated test: {len(scans)} scans, {len(injected)} repeat scans planted")
    print(f"  hash map found {len(fast)}, brute force found {len(slow)}, "
          f"same answer: {fast == slow == injected}")

    # speed
    print("\nSpeed")
    t0 = time.perf_counter()
    find_double_scans_bruteforce(scans)
    t_brute = time.perf_counter() - t0
    t0 = time.perf_counter()
    find_double_scans(scans)
    t_hash = time.perf_counter() - t0
    print(f"  {len(scans)} scans:  hash map {t_hash*1000:.2f} ms,  "
          f"brute force {t_brute*1000:.1f} ms  (~{t_brute/t_hash:.0f}x slower)")

    big, planted = make_scans(100_000, seed=9)
    book2 = ParcelBook()
    t0 = time.perf_counter()
    for t, h, w in big:
        book2.add_scan(t, h, w)
    t_build = time.perf_counter() - t0
    t0 = time.perf_counter()
    res = find_double_scans(big)
    t_check = time.perf_counter() - t0
    t0 = time.perf_counter()
    for i in range(0, 100_000, 7):
        book2.lookup(f"TRK{40000000 + i}")
    t_look = (time.perf_counter() - t0) / len(range(0, 100_000, 7))
    print(f"  {len(big)} scans, {len(book2)} parcels: built lookup in {t_build:.2f} s, "
          f"double-scan check {t_check:.2f} s ({len(res)} reported)")
    print(f"  matches the planted repeats: {({(t, h) for t, h, _ in res} == planted)}")
    print(f"  one lookup takes about {t_look*1e6:.2f} microseconds")


if __name__ == "__main__":
    main()
