"""
Task 5 - is a delivery route description a palindrome of hub codes?

"NAG - HYD - BLR - HYD - NAG" reads the same forwards and backwards, so it is
a there-and-back route. Case and separators (-, >, commas, spaces, slashes,
arrows...) are ignored.

Two pointers: one at the first hub, one at the last, move towards each other.
"""


def split_hubs(text):
    """Pull the hub codes out of the description. Anything that is not a
    letter or digit counts as a separator."""
    hubs, cur = [], ""
    for ch in text:
        if ch.isalnum():
            cur += ch.upper()
        elif cur:
            hubs.append(cur)
            cur = ""
    if cur:
        hubs.append(cur)
    return hubs


def is_route_palindrome(text):
    """Compare hub codes as whole units. Time O(n), space O(n) for the list."""
    hubs = split_hubs(text)
    left, right = 0, len(hubs) - 1
    while left < right:
        if hubs[left] != hubs[right]:
            return False
        left += 1
        right -= 1
    return True


def is_char_palindrome(text):
    """The classic version: two pointers on the raw string, skipping anything
    that is not a letter or digit. Time O(n), space O(1)."""
    left, right = 0, len(text) - 1
    while left < right:
        if not text[left].isalnum():
            left += 1
        elif not text[right].isalnum():
            right -= 1
        elif text[left].lower() != text[right].lower():
            return False
        else:
            left += 1
            right -= 1
    return True


TESTS = [
    "NAG-HYD-BLR-HYD-NAG",
    "nag > hyd > blr > hyd > NAG",
    "MAA // BLR // maa",
    "DEL, NAG, DEL",
    "NAG-DEL-BOM",
    "DEL-NAG-DEL-NAG",
    "BLR-MAA-CCU-MAA-BLR-",
    "DEL-AA-LED",
    "NAG",
    "",
    " - > - ",
]


def main():
    print(f"{'description':<32}{'hub codes':>11}{'char level':>12}")
    for t in TESTS:
        print(f"{repr(t):<32}{str(is_route_palindrome(t)):>11}{str(is_char_palindrome(t)):>12}")
    print("\nSplit example:", split_hubs("nag > Hyd/BLR , hyd-NAG"))
    print("\nNote: 'DEL-AA-LED' is True at character level (DELAALED) but False at hub level,")
    print("because the first hub DEL is not the same hub as the last one, LED.")


if __name__ == "__main__":
    main()
