"""Runs all five tasks one after another."""
import task1_bst, task2_scans, task3_routes, task4_window, task5_palindrome

for title, mod in [
    ("TASK 1 - BST of hub codes", task1_bst),
    ("TASK 2 - parcel hash map and double scans", task2_scans),
    ("TASK 3 - hub network, BFS and DFS", task3_routes),
    ("TASK 4 - busiest 4-hour window", task4_window),
    ("TASK 5 - route palindrome with two pointers", task5_palindrome),
]:
    print("=" * 70)
    print(title)
    print("=" * 70)
    mod.main()
    print()
