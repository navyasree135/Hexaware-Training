"""
Test cases for all five tasks. Every task has at least one test with EMPTY
input and one with DUPLICATES, because the task sheet asks for both.

Run with:  python -m unittest test_claims -v
"""

import inspect
import random
import unittest

from task1_bst import ClaimBST
from task2_hashing import ClaimTable, find_duplicates, make_key
from task3_graph import StageGraph, build_claim_graph
from task4_window import longest_run_above, brute_force
from task5_merge import merge_sorted


def tree_of(ids):
    t = ClaimBST()
    for i in ids:
        t.insert(i)
    return t


class TestTask1BST(unittest.TestCase):
    def test_empty_tree_traversals_are_empty(self):
        t = ClaimBST()
        self.assertEqual(t.inorder(), [])
        self.assertEqual(t.preorder(), [])
        self.assertEqual(t.postorder(), [])
        self.assertEqual(t.height(), 0)

    def test_empty_tree_search_finds_nothing(self):
        self.assertEqual(ClaimBST().search("CLM-1"), (False, []))

    def test_duplicate_id_is_ignored(self):
        t = tree_of(["CLM-2", "CLM-1", "CLM-3"])
        self.assertFalse(t.insert("CLM-1"))
        self.assertEqual(t.size, 3)
        self.assertEqual(t.inorder(), ["CLM-1", "CLM-2", "CLM-3"])

    def test_same_id_inserted_many_times_keeps_one_node(self):
        t = tree_of(["CLM-5"] * 4)
        self.assertEqual(t.size, 1)
        self.assertEqual(t.preorder(), ["CLM-5"])

    def test_single_node(self):
        t = tree_of(["CLM-9"])
        self.assertEqual(t.inorder(), t.preorder())
        self.assertEqual(t.height(), 1)

    def test_inorder_is_sorted(self):
        ids = [f"CLM-{n}" for n in random.Random(1).sample(range(1000, 2000), 60)]
        self.assertEqual(tree_of(ids).inorder(), sorted(ids))

    def test_preorder_and_postorder_on_small_tree(self):
        t = tree_of(["CLM-2", "CLM-1", "CLM-3"])
        self.assertEqual(t.preorder(), ["CLM-2", "CLM-1", "CLM-3"])
        self.assertEqual(t.postorder(), ["CLM-1", "CLM-3", "CLM-2"])

    def test_sorted_input_makes_a_line(self):
        ids = [f"CLM-{n}" for n in range(1000, 1015)]
        t = tree_of(ids)
        self.assertEqual(t.height(), 15)
        self.assertEqual(len(t.search("CLM-1014")[1]), 15)

    def test_search_missing_id(self):
        t = tree_of(["CLM-2", "CLM-1", "CLM-3"])
        self.assertFalse(t.search("CLM-7")[0])


class TestTask2Hashing(unittest.TestCase):
    def test_empty_input_has_no_duplicates(self):
        dups, table = find_duplicates([])
        self.assertEqual(dups, [])
        self.assertEqual(table.count, 0)

    def test_letter_case_duplicate(self):
        dups, _ = find_duplicates([("A", "POL-1", "2026-10-14"),
                                   ("B", "pol-1", "2026-10-14")])
        self.assertEqual(dups, [("B", "A")])

    def test_spacing_duplicate(self):
        dups, _ = find_duplicates([("A", "POL-1", "2026-10-14"),
                                   ("B", " POL- 1 ", "2026-10-14")])
        self.assertEqual(dups, [("B", "A")])

    def test_exact_copy_is_a_duplicate(self):
        dups, _ = find_duplicates([("A", "POL-1", "2026-10-14"),
                                   ("B", "POL-1", "2026-10-14")])
        self.assertEqual(len(dups), 1)

    def test_same_policy_different_date_is_not_a_duplicate(self):
        dups, _ = find_duplicates([("A", "POL-1", "2026-10-14"),
                                   ("B", "POL-1", "2026-10-15")])
        self.assertEqual(dups, [])

    def test_same_date_different_policy_is_not_a_duplicate(self):
        dups, _ = find_duplicates([("A", "POL-1", "2026-10-14"),
                                   ("B", "POL-2", "2026-10-14")])
        self.assertEqual(dups, [])

    def test_third_copy_points_to_the_first_claim(self):
        dups, _ = find_duplicates([("A", "POL-1", "d"), ("B", "pol-1", "d"),
                                   ("C", "POL -1", "d")])
        self.assertEqual(dups, [("B", "A"), ("C", "A")])

    def test_single_bucket_collides_but_stays_correct(self):
        claims = [("A", "POL-1", "d"), ("B", "POL-2", "d"),
                  ("C", "pol-1", "d"), ("D", "POL-3", "d")]
        dups, table = find_duplicates(claims, buckets=1)
        self.assertEqual(dups, [("C", "A")])
        self.assertEqual(table.longest_chain(), 3)

    def test_same_policy_other_date_in_same_chain_stays_separate(self):
        # with 1 bucket both claims sit in the same chain, so the table has
        # to compare the WHOLE key (policy and date), not just the policy
        claims = [("A", "POL-1", "2026-10-14"), ("B", "POL-1", "2026-10-15"),
                  ("C", "POL-2", "2026-10-14")]
        dups, table = find_duplicates(claims, buckets=1)
        self.assertEqual(dups, [])
        self.assertEqual(table.count, 3)

    def test_make_key_ignores_case_and_spaces(self):
        self.assertEqual(make_key(" pol - 77 ", "2026 -10-14"),
                         make_key("POL-77", "2026-10-14"))


class TestTask3Graph(unittest.TestCase):
    def test_empty_graph_has_no_loops(self):
        self.assertEqual(StageGraph().find_loops(), [])

    def test_unknown_stage_raises(self):
        with self.assertRaises(ValueError):
            StageGraph().shortest_path("a", "b")

    def test_path_to_itself(self):
        self.assertEqual(build_claim_graph().shortest_path("Surveyor", "Surveyor"),
                         ["Surveyor"])

    def test_shortest_path_uses_the_shortcut(self):
        g = build_claim_graph()
        self.assertEqual(g.shortest_path("Registration", "Settlement"),
                         ["Registration", "Assessment", "Settlement"])

    def test_no_path_backwards_from_settlement(self):
        self.assertIsNone(build_claim_graph().shortest_path("Settlement",
                                                            "Registration"))

    def test_bfs_ends_on_a_graph_with_loops(self):
        g = build_claim_graph()
        self.assertIsNone(g.shortest_path("Settlement", "Assessment"))

    def test_two_loops_found(self):
        loops = build_claim_graph().find_loops()
        self.assertEqual(len(loops), 2)
        for loop in loops:
            self.assertEqual(loop[0], loop[-1])

    def test_straight_flow_has_no_loop(self):
        self.assertEqual(build_claim_graph(False).find_loops(), [])

    def test_self_loop_is_detected(self):
        g = StageGraph()
        g.add_edge("Assessment", "Assessment")
        self.assertEqual(g.find_loops(), [["Assessment", "Assessment"]])

    def test_duplicate_edge_does_not_break_bfs(self):
        g = StageGraph()
        g.add_edge("a", "b")
        g.add_edge("a", "b")
        self.assertEqual(g.shortest_path("a", "b"), ["a", "b"])


class TestTask4Window(unittest.TestCase):
    def test_empty_input(self):
        self.assertEqual(longest_run_above([]), (0, None))

    def test_no_day_above_limit(self):
        self.assertEqual(longest_run_above([50, 100, 99]), (0, None))

    def test_exactly_100_is_not_above(self):
        self.assertEqual(longest_run_above([101, 100, 101, 101]), (2, 2))

    def test_every_day_above(self):
        self.assertEqual(longest_run_above([101] * 6), (6, 0))

    def test_run_at_the_very_end(self):
        self.assertEqual(longest_run_above([10, 20, 150, 160, 170]), (3, 2))

    def test_equal_runs_return_the_first(self):
        self.assertEqual(longest_run_above([120, 120, 5, 130, 130]), (2, 0))

    def test_same_value_repeated(self):
        self.assertEqual(longest_run_above([150, 150, 150, 50, 150]), (3, 0))

    def test_single_day_input(self):
        self.assertEqual(longest_run_above([101]), (1, 0))
        self.assertEqual(longest_run_above([100]), (0, None))

    def test_matches_brute_force_on_random_data(self):
        rng = random.Random(5)
        for _ in range(500):
            data = [rng.randint(90, 112) for _ in range(rng.randint(0, 40))]
            self.assertEqual(longest_run_above(data)[0], brute_force(data))


class TestTask5Merge(unittest.TestCase):
    def test_both_empty(self):
        self.assertEqual(merge_sorted([], []), [])

    def test_one_side_empty(self):
        self.assertEqual(merge_sorted([], [1, 2]), [1, 2])
        self.assertEqual(merge_sorted([1, 2], []), [1, 2])

    def test_duplicates_across_lists_are_kept(self):
        self.assertEqual(merge_sorted([1, 3], [3, 4]), [1, 3, 3, 4])

    def test_duplicates_can_be_dropped(self):
        self.assertEqual(merge_sorted([1, 3], [3, 4], keep_duplicates=False),
                         [1, 3, 4])

    def test_duplicates_inside_one_list(self):
        self.assertEqual(merge_sorted([2, 2, 2], [1]), [1, 2, 2, 2])
        self.assertEqual(merge_sorted([2, 2, 2], [1], False), [1, 2])

    def test_all_values_equal(self):
        self.assertEqual(merge_sorted([7, 7], [7, 7]), [7, 7, 7, 7])
        self.assertEqual(merge_sorted([7, 7], [7, 7], False), [7])

    def test_one_list_entirely_after_the_other(self):
        self.assertEqual(merge_sorted([5, 6], [1, 2]), [1, 2, 5, 6])

    def test_lists_of_different_length(self):
        self.assertEqual(merge_sorted([1], [0, 2, 3, 4]), [0, 1, 2, 3, 4])

    def test_inputs_are_not_changed(self):
        a, b = [1, 4], [2, 3]
        merge_sorted(a, b)
        self.assertEqual((a, b), ([1, 4], [2, 3]))

    def test_matches_sorted_on_random_data(self):
        rng = random.Random(9)
        for _ in range(300):
            a = sorted(rng.randint(0, 30) for _ in range(rng.randint(0, 15)))
            b = sorted(rng.randint(0, 30) for _ in range(rng.randint(0, 15)))
            self.assertEqual(merge_sorted(a, b), sorted(a + b))

    def test_merge_code_does_not_call_a_sort(self):
        self.assertNotIn("sort", inspect.getsource(merge_sorted).replace(
            "merge_sorted", ""))


if __name__ == "__main__":
    unittest.main(verbosity=2)
