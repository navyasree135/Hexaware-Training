"""
Task 5 - Merge two sorted claim lists from two regional offices into one
sorted list using two pointers. No sorting is done anywhere in the merge.
"""

import random
import time


def merge_sorted(a, b, keep_duplicates=True):
    """i walks along list a, j walks along list b. At each step we take the
    smaller of the two current items. When one list runs out, the rest of the
    other list is already in order, so it is copied across.
    If both lists have the same value, a's copy goes first (stable).
    With keep_duplicates=False a value that equals the last item written is
    skipped. Time O(m + n), extra space O(m + n) for the result only."""
    out = []
    i = j = 0

    def put(x):
        if keep_duplicates or not out or out[-1] != x:
            out.append(x)

    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            put(a[i])
            i += 1
        else:
            put(b[j])
            j += 1
    while i < len(a):
        put(a[i])
        i += 1
    while j < len(b):
        put(b[j])
        j += 1
    return out


# Claim numbers (the CLM- prefix is left off). Both lists are already sorted.
CHENNAI = [3004, 3011, 3019, 3027, 3027, 3040, 3052, 3066, 3071, 3085]
COIMBATORE = [3002, 3011, 3023, 3040, 3048, 3066, 3079, 3090, 3101]


def main():
    print("Chennai office   :", CHENNAI)
    print("Coimbatore office:", COIMBATORE)

    merged = merge_sorted(CHENNAI, COIMBATORE)
    print(f"\nMerged, keeping duplicates ({len(merged)} claims):")
    print(" ", merged)
    print("  same as sorted(a + b)?", merged == sorted(CHENNAI + COIMBATORE))

    unique = merge_sorted(CHENNAI, COIMBATORE, keep_duplicates=False)
    print(f"\nMerged, dropping duplicates ({len(unique)} claims):")
    print(" ", unique)
    shared = sorted(set(CHENNAI) & set(COIMBATORE))
    print("  claims that reached both offices:", shared)

    print("\nEdge cases:")
    print("  both empty        ->", merge_sorted([], []))
    print("  one empty         ->", merge_sorted([], [5, 9]))
    print("  all of a < all of b ->", merge_sorted([1, 2], [3, 4]))
    print("  all equal         ->", merge_sorted([7, 7], [7, 7]),
          "| dropped ->", merge_sorted([7, 7], [7, 7], False))

    # speed against the built-in sort
    rng = random.Random(3)
    a = sorted(rng.randint(1, 10 ** 7) for _ in range(300_000))
    b = sorted(rng.randint(1, 10 ** 7) for _ in range(300_000))
    t = time.perf_counter()
    m = merge_sorted(a, b)
    t_merge = time.perf_counter() - t
    t = time.perf_counter()
    s = sorted(a + b)
    t_sort = time.perf_counter() - t
    print("\n300,000 + 300,000 claim numbers:")
    print(f"  two-pointer merge {t_merge * 1000:8.1f} ms")
    print(f"  sorted(a + b)     {t_sort * 1000:8.1f} ms")
    print("  results equal:", m == s)


if __name__ == "__main__":
    main()
