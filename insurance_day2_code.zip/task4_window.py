"""
Task 4 - Longest run of consecutive days with more than 100 claims.

Sliding window of variable size: the right end moves one day at a time. If
the day is above the limit the window simply gets longer. If it is not, the
window is useless, so the left end jumps to the next day and we start again.
"""

import random
import time

LIMIT = 100


def longest_run_above(counts, limit=LIMIT):
    """Returns (length, start_index) of the longest run of days where the
    count is strictly MORE than the limit. If there is none, (0, None).
    When two runs tie, the earlier one is returned. Time O(n), space O(1)."""
    best_len, best_start = 0, None
    left = 0
    for right, c in enumerate(counts):
        if c <= limit:
            left = right + 1                 # window broken, restart after it
        elif right - left + 1 > best_len:
            best_len = right - left + 1
            best_start = left
    return best_len, best_start


def all_runs_above(counts, limit=LIMIT):
    """Every run (start, length), only used to print and to explain."""
    runs, start = [], None
    for i, c in enumerate(counts + [limit]):  # sentinel closes the last run
        if c > limit and start is None:
            start = i
        elif c <= limit and start is not None:
            runs.append((start, i - start))
            start = None
    return runs


def brute_force(counts, limit=LIMIT):
    """Slow check: from every day, keep walking while the day is above."""
    best = 0
    for i in range(len(counts)):
        j = i
        while j < len(counts) and counts[j] > limit:
            j += 1
        best = max(best, j - i)
    return best


def make_daily_claims():
    """30 days of made-up data, 1 to 30 October 2026. A cyclone hits on day
    12, so claims jump from day 13 onwards. Day 23 is exactly 100 on purpose
    to test the 'more than 100' rule."""
    rng = random.Random(7)
    counts = [rng.randint(62, 96) for _ in range(30)]
    for d in (5, 6):                          # a small early bump
        counts[d - 1] = rng.randint(104, 118)
    for d in range(13, 23):                   # the spike after the cyclone
        counts[d - 1] = rng.randint(120, 260)
    counts[22] = 100                          # day 23: exactly 100
    for d in range(24, 27):                   # a smaller second wave
        counts[d - 1] = rng.randint(105, 150)
    return counts


def main():
    counts = make_daily_claims()
    print("Claims per day (day 1 = 1 Oct 2026):")
    for i in range(0, 30, 10):
        row = "  ".join(f"d{i + k + 1:<2}={counts[i + k]:>3}" for k in range(10))
        print("  " + row)

    print("\nRuns of days above", LIMIT, "(day numbers):")
    for start, length in all_runs_above(counts):
        print(f"  day {start + 1} to day {start + length}  ({length} days)")

    length, start = longest_run_above(counts)
    print(f"\nLongest run: {length} days, day {start + 1} to day "
          f"{start + length}, i.e. {start + 1} Oct to {start + length} Oct")
    window = counts[start:start + length]
    print(f"  total claims in that run: {sum(window)}, "
          f"lowest day {min(window)}, highest day {max(window)}")
    print("  brute-force check gives", brute_force(counts), "days")

    # speed on a long record (about 27 years of days)
    rng = random.Random(1)
    long_counts = [rng.randint(60, 140) for _ in range(10_000)]
    # make one very long run so the brute force has real work to do
    for i in range(2000, 7000):
        long_counts[i] = 120
    t = time.perf_counter()
    a = longest_run_above(long_counts)
    t_fast = time.perf_counter() - t
    t = time.perf_counter()
    b = brute_force(long_counts)
    t_slow = time.perf_counter() - t
    print(f"\n10,000 days with one run of 5,000+:")
    print(f"  sliding window {t_fast * 1000:7.2f} ms -> {a[0]} days")
    print(f"  brute force    {t_slow * 1000:7.2f} ms -> {b} days")


if __name__ == "__main__":
    main()
