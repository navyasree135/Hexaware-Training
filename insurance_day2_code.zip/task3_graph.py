"""
Task 3 - Claim approval stages as a directed graph.

Each stage is a node and each "can move on to" is an arrow (edge).
  - BFS finds the shortest path between two stages (fewest hops).
  - DFS finds loops (a stage that can lead back to itself).
"""

from collections import deque


class StageGraph:
    def __init__(self):
        self.adj = {}                       # stage -> list of next stages

    def add_stage(self, name):
        self.adj.setdefault(name, [])

    def add_edge(self, a, b):
        self.add_stage(a)
        self.add_stage(b)
        self.adj[a].append(b)

    # ---- BFS: shortest path -------------------------------------------
    def shortest_path(self, start, goal):
        """Fewest-hops path from start to goal, or None if there is none.
        BFS visits stages level by level, so the first time we reach the
        goal is also the shortest way there. Time O(V + E)."""
        if start not in self.adj or goal not in self.adj:
            raise ValueError("unknown stage")
        parent = {start: None}              # also works as the 'visited' set
        queue = deque([start])
        while queue:
            stage = queue.popleft()
            if stage == goal:
                path = []
                while stage is not None:    # walk back through the parents
                    path.append(stage)
                    stage = parent[stage]
                return path[::-1]
            for nxt in self.adj[stage]:
                if nxt not in parent:       # without this check a loop would
                    parent[nxt] = stage     # keep BFS running forever
                    queue.append(nxt)
        return None

    # ---- DFS: loop detection ------------------------------------------
    def find_loops(self):
        """Returns a list of loops, each one written as a list of stages
        that starts and ends on the same stage.
        Colours: WHITE = not seen, GREY = on the current path, BLACK = done.
        An edge that points to a GREY stage closes a loop. Time O(V + E)."""
        WHITE, GREY, BLACK = 0, 1, 2
        colour = {s: WHITE for s in self.adj}
        path = []
        loops = []

        def visit(stage):
            colour[stage] = GREY
            path.append(stage)
            for nxt in self.adj[stage]:
                if colour[nxt] == GREY:                  # back edge = loop
                    loops.append(path[path.index(nxt):] + [nxt])
                elif colour[nxt] == WHITE:
                    visit(nxt)
            path.pop()
            colour[stage] = BLACK

        for s in self.adj:
            if colour[s] == WHITE:
                visit(s)
        return loops


def build_claim_graph(with_send_backs=True):
    g = StageGraph()
    g.add_edge("Registration", "Assessment")
    g.add_edge("Assessment", "Surveyor")           # big claims need a surveyor
    g.add_edge("Assessment", "Settlement")         # small claims skip him
    g.add_edge("Surveyor", "Settlement")
    if with_send_backs:
        g.add_edge("Assessment", "Registration")   # documents missing
        g.add_edge("Surveyor", "Assessment")       # surveyor wants re-assessment
    return g


def main():
    g = build_claim_graph()
    print("Stages and where each one can lead:")
    for stage, nxt in g.adj.items():
        print(f"  {stage:<13}-> {', '.join(nxt) if nxt else '(end)'}")

    print("\nShortest paths (BFS):")
    for a, b in [("Registration", "Settlement"),
                 ("Registration", "Surveyor"),
                 ("Surveyor", "Registration"),
                 ("Settlement", "Registration")]:
        p = g.shortest_path(a, b)
        if p is None:
            print(f"  {a} -> {b}: no path")
        else:
            print(f"  {a} -> {b}: {' > '.join(p)}  ({len(p) - 1} hop(s))")

    print("\nLoop detection (DFS), with the send-back steps:")
    for loop in g.find_loops():
        print("  loop:", " > ".join(loop))

    clean = build_claim_graph(with_send_backs=False)
    print("\nSame graph without the two send-back steps:")
    loops = clean.find_loops()
    print("  loops found:", len(loops), "(a straight forward flow)")
    print("  Registration -> Settlement:",
          " > ".join(clean.shortest_path("Registration", "Settlement")))


if __name__ == "__main__":
    main()
