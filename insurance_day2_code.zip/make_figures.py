"""Draws Figure 1 (approval stages graph) and Figure 2 (claims per day).
Only this file needs matplotlib."""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

from task3_graph import build_claim_graph
from task4_window import make_daily_claims, longest_run_above, LIMIT


def figure_graph():
    g = build_claim_graph()
    pos = {"Registration": (0, 0), "Assessment": (3, 0),
           "Surveyor": (6, 0), "Settlement": (9, 0)}
    fig, ax = plt.subplots(figsize=(9, 3.0))
    ax.set_xlim(-1.2, 10.2)
    ax.set_ylim(-1.9, 1.3)
    ax.axis("off")
    boxes = {}
    for name, (x, y) in pos.items():
        boxes[name] = ax.text(x, y, name, ha="center", va="center", fontsize=10,
                              bbox=dict(boxstyle="round,pad=0.45", fc="#eef3f8",
                                        ec="#1f4e79"), zorder=3)
    # (from, to, curvature, colour). For left-to-right arrows a positive
    # curvature bends downwards, for right-to-left arrows it is the other way.
    arrows = [
        ("Registration", "Assessment", 0.0, "#1f4e79"),
        ("Assessment", "Surveyor", 0.0, "#1f4e79"),
        ("Surveyor", "Settlement", 0.0, "#1f4e79"),
        ("Assessment", "Settlement", 0.4, "#1f4e79"),     # bends downwards
        ("Assessment", "Registration", 0.4, "#b03a2e"),   # bends upwards
        ("Surveyor", "Assessment", 0.4, "#b03a2e"),       # bends upwards
    ]
    for a_, b_, rad, col in arrows:
        ax.annotate("", xy=pos[b_], xytext=pos[a_], zorder=2,
                    arrowprops=dict(arrowstyle="-|>", color=col, lw=1.6,
                                    mutation_scale=16, shrinkA=0, shrinkB=0,
                                    connectionstyle=f"arc3,rad={rad}",
                                    patchA=boxes[a_].get_bbox_patch(),
                                    patchB=boxes[b_].get_bbox_patch()))
    ax.text(4.5, -1.7, "blue = forward steps        red = send-back steps (the loops)",
            ha="center", fontsize=9, color="#444")
    fig.tight_layout()
    fig.savefig("fig1_stages.png", dpi=200, bbox_inches="tight")
    plt.close(fig)


def figure_claims():
    counts = make_daily_claims()
    length, start = longest_run_above(counts)
    days = list(range(1, len(counts) + 1))
    fig, ax = plt.subplots(figsize=(9, 3.4))
    colours = ["#c0504d" if c > LIMIT else "#9bb3cc" for c in counts]
    ax.bar(days, counts, color=colours, width=0.8)
    ax.axhline(LIMIT, color="#333", lw=1, ls="--")
    ax.text(30.6, LIMIT + 4, "limit 100", fontsize=8, ha="right")
    ax.axvspan(start + 0.5, start + length + 0.5, color="#f4d9a8", alpha=0.45, zorder=0)
    ax.annotate(f"longest run: {length} days", xy=(start + length / 2 + 0.5, 270),
                ha="center", fontsize=9)
    ax.axvline(12.5, color="#555", lw=1, ls=":")
    ax.text(12.3, 240, "cyclone\n(day 12)", ha="right", fontsize=8, color="#555")
    ax.set_ylim(0, 290)
    ax.set_xlim(0.3, 30.7)
    ax.set_xlabel("day of October 2026")
    ax.set_ylabel("claims received")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig("fig2_claims.png", dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    figure_graph()
    figure_claims()
    print("saved fig1_stages.png and fig2_claims.png")
