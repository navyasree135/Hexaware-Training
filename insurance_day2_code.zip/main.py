"""Runs all five tasks one after another."""

import task1_bst
import task2_hashing
import task3_graph
import task4_window
import task5_merge

for title, module in [
    ("TASK 1 - BST of claim IDs", task1_bst),
    ("TASK 2 - Duplicate claims with hashing", task2_hashing),
    ("TASK 3 - Approval stages as a graph", task3_graph),
    ("TASK 4 - Longest run of days above 100 claims", task4_window),
    ("TASK 5 - Merging two regional lists", task5_merge),
]:
    print("=" * 78)
    print(title)
    print("=" * 78)
    module.main()
    print()
