"""
Task 2 - Finding duplicate / near-duplicate claims with hashing.

Two claims are treated as the same if they have the same policy number and
the same incident date, even when the text differs only in letter case or
spacing ("pol-8841" and "POL- 8841" are the same policy).

The hash table is my own, with separate chaining. Python's built-in hash()
for strings changes from run to run, so I wrote a small fixed hash function
to get the same output every time.
"""

import random
import time


def make_key(policy, incident_date):
    """Clean up the two fields so that case and spacing no longer matter."""
    policy = "".join(policy.split()).upper()          # drop ALL spaces
    incident_date = "".join(incident_date.split())
    return policy + "|" + incident_date


def my_hash(text):
    """Simple polynomial hash (multiply by 31 and add the next character)."""
    h = 0
    for ch in text:
        h = (h * 31 + ord(ch)) % (2 ** 32)
    return h


class ClaimTable:
    def __init__(self, buckets=8):
        self.buckets = [[] for _ in range(buckets)]   # each bucket is a chain
        self.count = 0

    def _bucket(self, key):
        return self.buckets[my_hash(key) % len(self.buckets)]

    def add(self, claim_id, policy, incident_date):
        """Returns (is_duplicate, first_claim_id).
        If the key is already stored we report the claim that came first and
        do not store the new one. Average time O(1), worst case O(n)."""
        key = make_key(policy, incident_date)
        chain = self._bucket(key)
        for stored_key, stored_id in chain:
            if stored_key == key:                     # compare the FULL key,
                return True, stored_id                # not just the bucket
        chain.append((key, claim_id))
        self.count += 1
        return False, claim_id

    def longest_chain(self):
        return max(len(c) for c in self.buckets)


# ---- sample data (made up) ------------------------------------------------
CLAIMS = [
    # claim id,   policy number,  incident date
    ("CLM-2001", "POL-8841",      "2026-10-14"),
    ("CLM-2002", "POL-1275",      "2026-10-14"),
    ("CLM-2003", "pol-8841",      "2026-10-14"),   # same as 2001, lower case
    ("CLM-2004", "POL-3390",      "2026-10-15"),
    ("CLM-2005", "POL- 1275",     "2026-10-14"),   # same as 2002, extra space
    ("CLM-2006", "POL-8841",      "2026-10-16"),   # same policy, other date
    ("CLM-2007", "POL-5527",      "2026-10-15"),
    ("CLM-2008", "Pol-3390 ",     "2026-10-15"),   # same as 2004, case + space
    ("CLM-2009", "POL-6012",      "2026-10-17"),
    ("CLM-2010", "POL-5527",      "2026-10-15"),   # exact copy of 2007
    ("CLM-2011", "POL-7788",      "2026-10-17"),
    ("CLM-2012", "POL-4096",      "2026-10-18"),
]


def find_duplicates(claims, buckets=8):
    table = ClaimTable(buckets)
    dups = []
    for claim_id, policy, date in claims:
        is_dup, first = table.add(claim_id, policy, date)
        if is_dup:
            dups.append((claim_id, first))
    return dups, table


def find_duplicates_with_set(claims):
    """Same job with Python's built-in dict, used to cross-check my table."""
    seen = {}
    dups = []
    for claim_id, policy, date in claims:
        key = make_key(policy, date)
        if key in seen:
            dups.append((claim_id, seen[key]))
        else:
            seen[key] = claim_id
    return dups


def main():
    dups, table = find_duplicates(CLAIMS, buckets=8)
    print(f"Checked {len(CLAIMS)} claims, {table.count} unique, "
          f"{len(dups)} duplicates found:")
    for later, first in dups:
        print(f"  {later} is a duplicate of {first}")

    print("\nHow the unique claims sit in the 8 buckets:")
    for i, chain in enumerate(table.buckets):
        keys = ", ".join(k for k, _ in chain) if chain else "-"
        note = "   <- collision" if len(chain) > 1 else ""
        print(f"  bucket {i}: {keys}{note}")

    print("\nCross-check with the built-in dict:",
          "same result" if dups == find_duplicates_with_set(CLAIMS)
          else "DIFFERENT!")

    # What if everything lands in ONE bucket? It should still be correct.
    dups_one, t1 = find_duplicates(CLAIMS, buckets=1)
    print(f"\nWith only 1 bucket (every claim collides): longest chain = "
          f"{t1.longest_chain()}, duplicates found = {len(dups_one)} "
          f"({'same answer' if dups_one == dups else 'WRONG'})")

    # Speed: why does the number of buckets matter?
    rng = random.Random(42)
    n = 20000
    big = []
    for i in range(n):
        policy = f"POL-{rng.randint(1000, 9999)}"
        date = f"2026-10-{rng.randint(10, 28)}"
        big.append((f"CLM-{i}", policy, date))

    print(f"\nTiming on {n:,} generated claims:")
    for buckets in (8, 64, 32768):
        start = time.perf_counter()
        d, t = find_duplicates(big, buckets)
        secs = time.perf_counter() - start
        print(f"  {buckets:>6} buckets: {secs * 1000:8.1f} ms, "
              f"longest chain {t.longest_chain():>5}, duplicates {len(d)}")
    start = time.perf_counter()
    d = find_duplicates_with_set(big)
    secs = time.perf_counter() - start
    print(f"  built-in dict : {secs * 1000:8.1f} ms, duplicates {len(d)}")


if __name__ == "__main__":
    main()
