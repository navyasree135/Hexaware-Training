"""
Task 1 - Binary Search Tree of claim IDs.

Insert and search, plus the three traversals (inorder, preorder, postorder).
Claim IDs look like "CLM-1056". They all have the same length, so comparing
them as plain text puts them in the right numeric order.
"""

import textwrap


class Node:
    def __init__(self, claim_id):
        self.claim_id = claim_id
        self.left = None
        self.right = None


class ClaimBST:
    def __init__(self):
        self.root = None
        self.size = 0

    def insert(self, claim_id):
        """Add a claim ID. If it is already in the tree we ignore it, because
        the same claim should never be stored twice.
        Returns True if it was added. Time: O(h), h = height of the tree."""
        new = Node(claim_id)
        if self.root is None:
            self.root = new
            self.size = 1
            return True

        cur = self.root
        while True:
            if claim_id == cur.claim_id:
                return False                      # duplicate
            if claim_id < cur.claim_id:
                if cur.left is None:
                    cur.left = new
                    break
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = new
                    break
                cur = cur.right
        self.size += 1
        return True

    def search(self, claim_id):
        """Returns (found, path). path is every claim we looked at on the
        way down, so we can count how many steps the search took."""
        path = []
        cur = self.root
        while cur is not None:
            path.append(cur.claim_id)
            if claim_id == cur.claim_id:
                return True, path
            cur = cur.left if claim_id < cur.claim_id else cur.right
        return False, path

    # ---- the three traversals. Only WHEN we write the node down changes.

    def inorder(self):
        """left, node, right -> sorted order for a BST"""
        out = []

        def walk(node):
            if node:
                walk(node.left)
                out.append(node.claim_id)
                walk(node.right)
        walk(self.root)
        return out

    def preorder(self):
        """node, left, right -> parents before children"""
        out = []

        def walk(node):
            if node:
                out.append(node.claim_id)
                walk(node.left)
                walk(node.right)
        walk(self.root)
        return out

    def postorder(self):
        """left, right, node -> children before parents"""
        out = []

        def walk(node):
            if node:
                walk(node.left)
                walk(node.right)
                out.append(node.claim_id)
        walk(self.root)
        return out

    def height(self):
        """Number of levels (a tree with only a root has height 1)."""
        def h(node):
            return 0 if node is None else 1 + max(h(node.left), h(node.right))
        return h(self.root)

    def draw(self):
        """Print the tree sideways: root on the left, right children on top."""
        lines = []

        def walk(node, depth):
            if node:
                walk(node.right, depth + 1)
                lines.append("    " * depth + node.claim_id)
                walk(node.left, depth + 1)
        walk(self.root, 0)
        return lines


# 15 claim IDs in the order they "arrived". I did not arrange them to keep
# the tree balanced, because real claims do not arrive in a nice order.
ARRIVAL_ORDER = [
    "CLM-1056", "CLM-1033", "CLM-1078", "CLM-1019", "CLM-1041",
    "CLM-1063", "CLM-1091", "CLM-1012", "CLM-1027", "CLM-1048",
    "CLM-1070", "CLM-1085", "CLM-1099", "CLM-1004", "CLM-1107",
]


def main():
    tree = ClaimBST()
    for c in ARRIVAL_ORDER:
        tree.insert(c)
    print(f"Inserted {tree.size} claim IDs, tree height = {tree.height()}")
    print("Trying to insert CLM-1041 again ->", tree.insert("CLM-1041"),
          "(duplicate ignored)")

    print("\nTree (sideways, root on the left):")
    for line in tree.draw():
        print("  " + line)
    print()

    for label, result in [("Inorder", tree.inorder()),
                          ("Preorder", tree.preorder()),
                          ("Postorder", tree.postorder())]:
        print(textwrap.fill(", ".join(result), width=88,
                            initial_indent=f"{label + ':':<11}",
                            subsequent_indent=" " * 11))

    print("\nSearching")
    for cid in ["CLM-1048", "CLM-1107", "CLM-1063", "CLM-1050"]:
        found, path = tree.search(cid)
        verdict = "found    " if found else "NOT found"
        print(f"  {cid}  {verdict} after {len(path)} step(s): {' > '.join(path)}")

    # what if the claims were entered in sorted order instead?
    line_tree = ClaimBST()
    for c in sorted(ARRIVAL_ORDER):
        line_tree.insert(c)
    found, path = line_tree.search("CLM-1107")
    print("\nSame 15 IDs inserted in sorted order instead:")
    print(f"  height = {line_tree.height()} (the tree becomes a straight line)")
    print(f"  searching CLM-1107 takes {len(path)} steps, "
          f"against {len(tree.search('CLM-1107')[1])} in the first tree")
    print("  inorder is still the same:", line_tree.inorder() == tree.inorder())


if __name__ == "__main__":
    main()
