"""
main.py - runs all five tasks one after another.
Usage:  python main.py
(No input files needed. The sample data is generated inside the task files with fixed seeds.)
"""
import time

import task1_bst
import task2_hashing
import task3_graph
import task4_window
import task5_pairs


def banner(text):
    print("\n" + "=" * 78)
    print(text)
    print("=" * 78)


def main():
    start = time.perf_counter()
    banner("TASK 1 - Binary Search Tree of product categories")
    task1_bst.main()
    banner("TASK 2 - SKU look-up: hash table with chaining vs built-in dict")
    task2_hashing.main()
    banner("TASK 3 - Microservice deployment order (graph, BFS / DFS, cycle)")
    task3_graph.main()
    banner("TASK 4 - Busiest 3-hour window (sliding window)")
    task4_window.main()
    banner("TASK 5 - Gift-card pairs (two pointers)")
    task5_pairs.main()
    print(f"\nAll tasks finished in {time.perf_counter() - start:.1f} s")


if __name__ == "__main__":
    main()
