"""
Task 3 - Microservice deployment order as a graph.
An edge  A -> B  means "A depends on B", so B has to be deployed before A.
  * DFS gives a valid order (a service is added after all of its dependencies)
  * BFS (Kahn's algorithm) gives a valid order in "waves" of services that can go together
  * A circular dependency is detected with DFS colours (and Kahn also notices it)
"""
import textwrap
from collections import deque

# service -> services it needs to be running first
DEPENDS_ON = {
    "api-gateway":    ["auth", "cart", "search"],
    "checkout":       ["cart", "payment", "notification"],
    "cart":           ["pricing", "auth"],
    "pricing":        ["inventory"],
    "search":         ["inventory", "database"],
    "recommendation": ["search", "inventory"],
    "payment":        ["auth", "database"],
    "inventory":      ["database"],
    "auth":           ["database"],
    "notification":   ["queue"],
    "queue":          [],
    "database":       [],
}


def dfs_order(graph):
    """Deployment order using DFS. We go down to the dependencies first and add a
    service to the list only after all of its dependencies are in it.
    Raises ValueError (showing the loop) if there is a circular dependency.
    Time: O(V + E)"""
    WHITE, GREY, BLACK = 0, 1, 2          # not seen / on the current path / finished
    colour = {s: WHITE for s in graph}
    order = []
    path = []

    def visit(s):
        colour[s] = GREY
        path.append(s)
        for dep in sorted(graph[s]):
            if colour[dep] == GREY:       # reached a service that is still open -> loop
                loop = path[path.index(dep):] + [dep]
                raise ValueError(" -> ".join(loop))
            if colour[dep] == WHITE:
                visit(dep)
        path.pop()
        colour[s] = BLACK
        order.append(s)

    for s in sorted(graph):
        if colour[s] == WHITE:
            visit(s)
    return order


def bfs_order(graph):
    """Deployment order using BFS (Kahn's algorithm).
    waiting[s] = how many dependencies of s are not deployed yet.
    Services with 0 waiting go first; deploying one lowers the count of every
    service that depends on it. Returns a list of waves.
    If some services never reach 0, they are stuck in a cycle.
    Time: O(V + E)"""
    waiting = {s: len(deps) for s, deps in graph.items()}
    dependents = {s: [] for s in graph}   # reverse edges: who needs me?
    for s, deps in graph.items():
        for d in deps:
            dependents[d].append(s)

    queue = deque(sorted(s for s, n in waiting.items() if n == 0))
    waves, done = [], 0
    while queue:
        wave = list(queue)
        queue.clear()
        waves.append(wave)
        for s in wave:
            done += 1
            for nxt in sorted(dependents[s]):
                waiting[nxt] -= 1
                if waiting[nxt] == 0:
                    queue.append(nxt)
    if done != len(graph):
        stuck = sorted(s for s, n in waiting.items() if n > 0)
        raise ValueError(f"{len(stuck)} services can never start: " + ", ".join(stuck))
    return waves


def is_valid(order, graph):
    """Check that every service appears after all the services it depends on."""
    position = {s: i for i, s in enumerate(order)}
    return all(position[d] < position[s] for s, deps in graph.items() for d in deps)


def main():
    edges = sum(len(d) for d in DEPENDS_ON.values())
    print(f"Graph: {len(DEPENDS_ON)} services, {edges} dependencies")
    print("Edge 'A -> B' means A depends on B, so B is deployed first.\n")
    for s in DEPENDS_ON:
        if DEPENDS_ON[s]:
            print(f"  {s:<15} -> {', '.join(DEPENDS_ON[s])}")

    print("\n--- Valid deployment order with DFS ---")
    order = dfs_order(DEPENDS_ON)
    for i, s in enumerate(order, 1):
        print(f"  {i:>2}. {s}")
    print("  valid order:", is_valid(order, DEPENDS_ON))

    print("\n--- Valid deployment order with BFS (waves that can be deployed together) ---")
    waves = bfs_order(DEPENDS_ON)
    flat = []
    for i, wave in enumerate(waves, 1):
        print(f"  Wave {i}: {', '.join(wave)}")
        flat += wave
    print("  valid order:", is_valid(flat, DEPENDS_ON))

    print("\n--- Circular dependency ---")
    broken = {s: list(d) for s, d in DEPENDS_ON.items()}
    broken["inventory"].append("cart")        # inventory now also needs cart
    print("Added one more dependency: inventory -> cart")
    print("(cart -> pricing -> inventory -> cart is now a loop)")
    try:
        dfs_order(broken)
    except ValueError as e:
        print("  DFS detected the cycle :", e)
    try:
        bfs_order(broken)
    except ValueError as e:
        print(textwrap.fill(str(e), width=92, initial_indent="  BFS (Kahn) agrees      : ",
                            subsequent_indent=" " * 27))

    print(f"\nOriginal graph has no cycle: both methods placed all {len(DEPENDS_ON)} services.")


if __name__ == "__main__":
    main()
