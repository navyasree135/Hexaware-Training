"""
Task 2 - SKU look-up with my own hash table (separate chaining), then the same
thing with Python's built-in dict, timed on 100,000 SKUs.
"""
import random
import time


class HashTable:
    """Each bucket is a list. Keys whose hash lands in the same bucket (a
    collision) are simply stored one after another in that bucket's list."""

    def __init__(self, size=11):
        self.size = size
        self.buckets = [[] for _ in range(size)]
        self.count = 0

    def _hash(self, key):
        """Polynomial string hash: h = h * 31 + character code, kept below size."""
        h = 0
        for ch in key:
            h = (h * 31 + ord(ch)) % self.size
        return h

    def put(self, key, value):
        bucket = self.buckets[self._hash(key)]
        for pair in bucket:
            if pair[0] == key:            # SKU already there, just update it
                pair[1] = value
                return
        bucket.append([key, value])
        self.count += 1

    def get(self, key):
        """Look in one bucket only. Returns the value or None."""
        for k, v in self.buckets[self._hash(key)]:
            if k == key:
                return v
        return None

    def longest_chain(self):
        return max(len(b) for b in self.buckets)

    def load_factor(self):
        return self.count / self.size


def collision_demo():
    print("Part A: small table, 7 buckets, 9 SKUs")
    table = HashTable(size=7)
    items = [
        ("SKU-1001", "USB-C cable"), ("SKU-1002", "Phone case"),
        ("SKU-1003", "Steel bottle"), ("SKU-1004", "Notebook"),
        ("SKU-1005", "Desk lamp"), ("SKU-1006", "Headphones"),
        ("SKU-1007", "Yoga mat"), ("SKU-1008", "Backpack"),
        ("SKU-1009", "Mouse pad"),
    ]
    for sku, name in items:
        table.put(sku, name)
        print(f"  put {sku} -> bucket {table._hash(sku)}")

    print("\n  Buckets after inserting:")
    for i, b in enumerate(table.buckets):
        shown = " -> ".join(f"{k}" for k, _ in b) if b else "(empty)"
        print(f"    [{i}] {shown}")

    crowded = [i for i, b in enumerate(table.buckets) if len(b) > 1]
    i = crowded[0]
    a, b = table.buckets[i][0][0], table.buckets[i][1][0]
    print(f"\n  Collision: {a} and {b} both hash to bucket {i}.")
    print("  Both are kept in the same chain, so both can still be found:")
    print(f"    get({a}) = {table.get(a)!r}")
    print(f"    get({b}) = {table.get(b)!r}")
    print(f"    get('SKU-9999') = {table.get('SKU-9999')!r}  (not stocked)")
    print(f"  Load factor = {table.load_factor():.2f}, longest chain = {table.longest_chain()}")


def timing_demo():
    N = 100_000
    print(f"\nPart B: {N:,} SKUs, look up every one of them")
    skus = [f"SKU-{i:06d}" for i in range(N)]
    rng = random.Random(5)
    rng.shuffle(skus)                       # look-ups happen in random order

    # my hash table, with about one bucket per SKU
    mine = HashTable(size=100_003)
    t = time.perf_counter()
    for s in skus:
        mine.put(s, len(s))
    t_put_mine = time.perf_counter() - t

    built_in = {}
    t = time.perf_counter()
    for s in skus:
        built_in[s] = len(s)
    t_put_dict = time.perf_counter() - t

    t = time.perf_counter()
    for s in skus:
        mine.get(s)
    t_get_mine = time.perf_counter() - t

    t = time.perf_counter()
    for s in skus:
        built_in.get(s)
    t_get_dict = time.perf_counter() - t

    # for contrast: scanning a plain list, only 200 look-ups because it is so slow
    as_list = [(s, len(s)) for s in skus]
    sample = rng.sample(skus, 200)          # random positions, not just the front of the list
    t = time.perf_counter()
    for s in sample:
        for k, v in as_list:
            if k == s:
                break
    t_list = (time.perf_counter() - t) / len(sample) * N   # scaled up to 100,000 look-ups

    used = sum(1 for b in mine.buckets if b)
    print(f"  my table: {mine.size:,} buckets, load factor {mine.load_factor():.2f}, "
          f"{used:,} buckets used, longest chain {mine.longest_chain()}")
    print()
    print(f"  {'Method':<28}{'Insert (s)':>11}{'Look-up (s)':>13}{'Per look-up (us)':>18}")
    print("  " + "-" * 70)
    print(f"  {'my chained hash table':<28}{t_put_mine:>11.3f}{t_get_mine:>13.3f}"
          f"{t_get_mine / N * 1e6:>18.2f}")
    print(f"  {'built-in dict':<28}{t_put_dict:>11.3f}{t_get_dict:>13.3f}"
          f"{t_get_dict / N * 1e6:>18.2f}")
    print(f"  {'plain list scan (estimated)':<28}{'-':>11}{t_list:>13.1f}"
          f"{t_list / N * 1e6:>18.2f}")
    print("  " + "-" * 70)
    print(f"  dict look-ups are {t_get_mine / t_get_dict:.1f}x faster than my table")
    print(f"  my table is about {t_list / t_get_mine:,.0f}x faster than scanning a list")
    print("  (list time is measured on 200 look-ups and scaled up to 100,000)")


def main():
    collision_demo()
    timing_demo()


if __name__ == "__main__":
    main()
