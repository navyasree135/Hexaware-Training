"""
Task 5 - Gift card: find all pairs of orders whose values add up to the gift-card value.
The list is sorted, so two pointers are enough: one at the smallest value, one at the largest.
  sum too small -> move the left pointer right (we need something bigger)
  sum too big   -> move the right pointer left (we need something smaller)
  sum matches   -> record the pair and move on
"""
import random
import time


def find_pairs(values, target):
    """Returns a list of (i, j) index pairs with i < j and values[i] + values[j] == target.
    Orders with the same value are separate orders, so they all count.
    Time: O(n) to find the matches (plus the size of the answer), extra space O(1)."""
    pairs = []
    left, right = 0, len(values) - 1
    while left < right:
        s = values[left] + values[right]
        if s < target:
            left += 1
        elif s > target:
            right -= 1
        else:
            if values[left] == values[right]:
                # everything from left to right has the same value, pair them all up
                for i in range(left, right + 1):
                    for j in range(i + 1, right + 1):
                        pairs.append((i, j))
                break
            # find how many orders share the left value and the right value
            l_end = left
            while values[l_end + 1] == values[left]:
                l_end += 1
            r_start = right
            while values[r_start - 1] == values[right]:
                r_start -= 1
            for i in range(left, l_end + 1):
                for j in range(r_start, right + 1):
                    pairs.append((i, j))
            left, right = l_end + 1, r_start - 1
    return pairs


def find_pairs_bruteforce(values, target):
    """Check every pair. O(n^2). Only here to double-check the answer."""
    return [(i, j) for i in range(len(values)) for j in range(i + 1, len(values))
            if values[i] + values[j] == target]


def main():
    rng = random.Random(1)
    # 30 order values in rupees, multiples of 10 so that some repeat
    orders = sorted(rng.choice(range(100, 1000, 10)) for _ in range(30))
    gift_card = 1000

    print(f"{len(orders)} order values (sorted):")
    for k in range(0, len(orders), 10):
        print("  " + ", ".join(str(v) for v in orders[k:k + 10]))
    print(f"\nGift-card value: Rs {gift_card}")

    pairs = find_pairs(orders, gift_card)
    print(f"\nPairs found with two pointers: {len(pairs)}")
    print(f"  {'Order A':>8} {'Value':>6}   {'Order B':>8} {'Value':>6}   Sum")
    for i, j in pairs:
        a, b = "#" + str(i), "#" + str(j)
        print(f"  {a:>8} {orders[i]:>6}   {b:>8} {orders[j]:>6}   {orders[i] + orders[j]}")
    print("  (the # numbers are positions in the sorted list)")

    expected = find_pairs_bruteforce(orders, gift_card)
    print(f"\nBrute force check: {len(expected)} pairs -> "
          f"{'same pairs' if sorted(pairs) == sorted(expected) else 'MISMATCH'}")

    # speed comparison
    big = sorted(rng.randint(1, 5000) for _ in range(4000))
    t = time.perf_counter()
    a = find_pairs(big, 5000)
    t_two = time.perf_counter() - t
    t = time.perf_counter()
    b = find_pairs_bruteforce(big, 5000)
    t_brute = time.perf_counter() - t
    print(f"\nSpeed on {len(big):,} sorted values, target 5000 ({len(a)} pairs):")
    print(f"  two pointers : {t_two * 1000:9.2f} ms")
    print(f"  brute force  : {t_brute * 1000:9.2f} ms   (same pairs: {sorted(a) == sorted(b)})")
    print(f"  two pointers is about {t_brute / t_two:,.0f}x faster")

    print("\nEdge cases")
    print("  empty list           ->", find_pairs([], 10))
    print("  one order            ->", find_pairs([10], 10))
    print("  no pair possible     ->", find_pairs([1, 2, 3], 100))
    print("  [5, 5, 5, 5], target 10 ->", find_pairs([5, 5, 5, 5], 10), "(all 6 combinations)")


if __name__ == "__main__":
    main()
