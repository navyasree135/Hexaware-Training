"""
Task 1 - Binary Search Tree of product categories.
Insert and search, plus inorder / preorder / postorder traversals for 15 categories.
Category names are compared in lower case so "books" and "Books" are the same thing.
"""
import textwrap


class Node:
    def __init__(self, name):
        self.name = name
        self.left = None
        self.right = None


class CategoryBST:
    def __init__(self):
        self.root = None
        self.size = 0

    def insert(self, name):
        """Add a category. A name that is already in the tree is ignored.
        Returns True if it was added. Time: O(h), h = height of the tree."""
        new = Node(name)
        if self.root is None:
            self.root = new
            self.size = 1
            return True
        cur = self.root
        while True:
            if name.lower() == cur.name.lower():
                return False                      # duplicate
            if name.lower() < cur.name.lower():
                if cur.left is None:
                    cur.left = new
                    break
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = new
                    break
                cur = cur.right
        self.size += 1
        return True

    def search(self, name):
        """Returns (found, path). path is the list of categories we looked at
        on the way down, so we can see how many steps the search took."""
        path = []
        cur = self.root
        while cur is not None:
            path.append(cur.name)
            if name.lower() == cur.name.lower():
                return True, path
            cur = cur.left if name.lower() < cur.name.lower() else cur.right
        return False, path

    # ---- the three traversals (the only difference is WHEN we visit the node)
    def inorder(self):
        """left, node, right  -> alphabetical order for a BST"""
        out = []

        def walk(node):
            if node:
                walk(node.left)
                out.append(node.name)
                walk(node.right)
        walk(self.root)
        return out

    def preorder(self):
        """node, left, right  -> parents before children (good for copying a tree)"""
        out = []

        def walk(node):
            if node:
                out.append(node.name)
                walk(node.left)
                walk(node.right)
        walk(self.root)
        return out

    def postorder(self):
        """left, right, node  -> children before parents (good for deleting a tree)"""
        out = []

        def walk(node):
            if node:
                walk(node.left)
                walk(node.right)
                out.append(node.name)
        walk(self.root)
        return out

    def height(self):
        """Number of levels (a tree with only a root has height 1)."""
        def h(node):
            return 0 if node is None else 1 + max(h(node.left), h(node.right))
        return h(self.root)

    def draw(self):
        """Print the tree sideways: root on the left, right children on top."""
        lines = []

        def walk(node, depth):
            if node:
                walk(node.right, depth + 1)
                lines.append("      " * depth + node.name)
                walk(node.left, depth + 1)
        walk(self.root, 0)
        return lines


# 15 sample categories. I inserted them in this order on purpose (middle value
# first, then the middle of each half, and so on) so the tree stays balanced.
CATEGORIES = [
    "Grocery", "Clothing", "Pet Supplies", "Beauty", "Furniture",
    "Jewellery", "Stationery", "Automotive", "Books", "Electronics",
    "Garden", "Health", "Music", "Sports", "Toys",
]


def main():
    tree = CategoryBST()
    for c in CATEGORIES:
        tree.insert(c)
    print(f"Inserted {tree.size} categories, tree height = {tree.height()}")
    print("Trying to insert 'books' again ->", tree.insert("books"), "(duplicate ignored)")

    print("\nTree (sideways, root on the left):")
    for line in tree.draw():
        print("  " + line)

    print()
    for label, result in [("Inorder", tree.inorder()), ("Preorder", tree.preorder()),
                          ("Postorder", tree.postorder())]:
        print(textwrap.fill(", ".join(result), width=86, initial_indent=f"{label + ':':<11}",
                            subsequent_indent=" " * 11))

    print("\nSearching")
    for name in ["Music", "Electronics", "Toys", "Laptops"]:
        found, path = tree.search(name)
        verdict = "found    " if found else "NOT found"
        print(f"  {name:<12} {verdict} after {len(path)} step(s): {' > '.join(path)}")

    # what happens if the categories arrive already sorted?
    sorted_tree = CategoryBST()
    for c in sorted(CATEGORIES):
        sorted_tree.insert(c)
    found, path = sorted_tree.search("Toys")
    print("\nSame 15 categories inserted in alphabetical order instead:")
    print(f"  height = {sorted_tree.height()} (it becomes a straight line)")
    balanced_steps = len(tree.search("Toys")[1])
    print(f"  searching 'Toys' now takes {len(path)} steps, "
          f"against {balanced_steps} in the balanced tree")
    print("  inorder is still the same:", sorted_tree.inorder() == tree.inorder())


if __name__ == "__main__":
    main()
