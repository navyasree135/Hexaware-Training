"""make_figures.py - draws the BST (fig_bst.png) and the traffic chart (fig_traffic.png)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from task1_bst import CategoryBST, CATEGORIES
from task4_window import generate_traffic, busiest_window, WINDOW, clock

BLUE, ORANGE, GREY, DARK = "#2f6fb0", "#e08a2e", "#b5bac2", "#333333"

# ---------------------------------------------------------------- BST drawing
tree = CategoryBST()
for c in CATEGORIES:
    tree.insert(c)

pos = {}          # node name -> (x, y)
counter = [0]


def place(node, depth):
    """x = position in inorder (so left-to-right is alphabetical), y = depth."""
    if node is None:
        return
    place(node.left, depth + 1)
    pos[node.name] = (counter[0], -depth)
    counter[0] += 1
    place(node.right, depth + 1)


place(tree.root, 0)

fig, ax = plt.subplots(figsize=(11, 3.6))


def edges(node):
    if node is None:
        return
    for child in (node.left, node.right):
        if child:
            (x1, y1), (x2, y2) = pos[node.name], pos[child.name]
            ax.plot([x1, x2], [y1, y2], color=GREY, lw=1.4, zorder=1)
            edges(child)


edges(tree.root)
for name, (x, y) in pos.items():
    is_root = name == tree.root.name
    ax.text(x, y, name, ha="center", va="center", fontsize=8.5, zorder=2,
            color="white" if is_root else DARK,
            bbox=dict(boxstyle="round,pad=0.35", fc=BLUE if is_root else "white",
                      ec=BLUE, lw=1.2))
ax.set_xlim(-0.8, counter[0] - 0.2)
ax.set_ylim(-3.5, 0.5)
ax.axis("off")
ax.set_title("Category tree after inserting the 15 categories (height 4)",
             fontsize=11, color=DARK)
plt.tight_layout()
plt.savefig("fig_bst.png", dpi=170)
plt.close()

# ---------------------------------------------------------------- traffic chart
data = generate_traffic()
start, total = busiest_window(data)
hours = [m / 60 for m in range(len(data))]

fig, ax = plt.subplots(figsize=(11, 3.6))
ax.plot(hours, data, color=GREY, lw=0.8, label="requests per minute")
ax.axvspan(start / 60, (start + WINDOW) / 60, color=ORANGE, alpha=0.25,
           label=f"busiest 3 hours ({clock(start)} to {clock(start + WINDOW - 1)})")
ax.plot(hours[start:start + WINDOW], data[start:start + WINDOW], color=ORANGE, lw=1.0)
ax.set_xlim(0, 24)
ax.set_xticks(range(0, 25, 2))
ax.set_xticklabels([f"{h:02d}:00" for h in range(0, 25, 2)], fontsize=8)
ax.set_ylabel("requests per minute")
ax.set_title("24 hours of traffic and the busiest continuous 3-hour window",
             fontsize=11, color=DARK)
ax.legend(frameon=False, loc="upper left", fontsize=9)
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
plt.savefig("fig_traffic.png", dpi=170)
print("saved fig_bst.png and fig_traffic.png")
