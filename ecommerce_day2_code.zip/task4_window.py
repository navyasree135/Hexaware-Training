"""
Task 4 - Busiest continuous 3-hour window in 24 hours of traffic.
We have one number per minute (1,440 of them), so a 3-hour window is 180 minutes.
Sliding window: add the new minute, subtract the minute that falls out.
"""
import math
import random
import time

WINDOW = 3 * 60                  # 3 hours in minutes
SCALE = 30                       # makes the made-up traffic look like a busy shop
ASSUMED_SERVER_RPS = 50          # ASSUMPTION for the sizing example, not a measured value


def generate_traffic(minutes=24 * 60, seed=11):
    """Made-up requests per minute: quiet at night, a small lunch bump and a big
    evening peak, plus some random noise."""
    rng = random.Random(seed)
    data = []
    for m in range(minutes):
        hour = m / 60
        base = 150
        base += 220 * math.exp(-((hour - 13) ** 2) / 4)      # lunch bump around 13:00
        base += 650 * math.exp(-((hour - 20.5) ** 2) / 5)    # evening peak around 20:30
        base -= 70 * math.exp(-((hour - 4) ** 2) / 6)        # very quiet around 04:00
        data.append(max(0, int((base + rng.gauss(0, 25)) * SCALE)))
    return data


def clock(minute):
    return f"{minute // 60:02d}:{minute % 60:02d}"


def busiest_window(data, k=WINDOW):
    """Returns (start_index, total). Time O(n), extra space O(1)."""
    if k <= 0 or len(data) < k:
        raise ValueError("window is bigger than the data")
    current = sum(data[:k])                  # first window
    best, best_start = current, 0
    for i in range(k, len(data)):
        current += data[i] - data[i - k]     # slide by one minute
        if current > best:
            best, best_start = current, i - k + 1
    return best_start, best


def busiest_window_bruteforce(data, k=WINDOW):
    """Add up every window from scratch. O(n * k). Only used to double-check."""
    best, best_start = -1, 0
    for i in range(len(data) - k + 1):
        total = sum(data[i:i + k])
        if total > best:
            best, best_start = total, i
    return best_start, best


def main():
    data = generate_traffic()
    print(f"{len(data)} readings (requests per minute for 24 hours), "
          f"window = {WINDOW} minutes (3 hours)")
    print(f"Total requests in the day: {sum(data):,}")
    peak_minute = max(range(len(data)), key=lambda i: data[i])
    print(f"Single busiest minute    : {clock(peak_minute)} with {data[peak_minute]} requests\n")

    start, total = busiest_window(data)
    end = start + WINDOW
    print("Busiest 3-hour window (sliding window)")
    print(f"  from {clock(start)} to {clock(end - 1)}  "
          f"(minute {start} to minute {end - 1}, {WINDOW} minutes)")
    print(f"  total requests      : {total:,}")
    print(f"  average per minute  : {total / WINDOW:,.1f}")
    print(f"  average per second  : {total / WINDOW / 60:,.1f}")

    b_start, b_total = busiest_window_bruteforce(data)
    print(f"\nBrute force check: start {clock(b_start)}, total {b_total:,} -> "
          f"{'same answer' if (b_start, b_total) == (start, total) else 'MISMATCH'}")

    # requests per hour, with the hours inside the window marked
    print("\nRequests per hour (* = whole hour is inside the busiest window)")
    for h in range(24):
        hour_total = sum(data[h * 60:(h + 1) * 60])
        inside = start <= h * 60 and (h + 1) * 60 <= end
        bar = "#" * (hour_total // 45000)
        print(f"  {h:02d}:00  {hour_total:>9,}  {bar} {'*' if inside else ''}")

    # sizing example
    peak_rps = total / WINDOW / 60
    servers = math.ceil(peak_rps / ASSUMED_SERVER_RPS)
    print(f"\nSizing example (ASSUMING one server handles {ASSUMED_SERVER_RPS} requests/second):")
    print(f"  peak window needs about {peak_rps:.1f} req/s -> {servers} server(s) "
          f"(before adding any safety margin)")

    # speed comparison on a bigger input
    big = generate_traffic(minutes=100_000, seed=3)
    t = time.perf_counter()
    r1 = busiest_window(big)
    t_slide = time.perf_counter() - t
    t = time.perf_counter()
    r2 = busiest_window_bruteforce(big)
    t_brute = time.perf_counter() - t
    print(f"\nSpeed on {len(big):,} minutes of data (window still {WINDOW}):")
    print(f"  sliding window : {t_slide * 1000:8.1f} ms")
    print(f"  brute force    : {t_brute * 1000:8.1f} ms   (same answer: {r1 == r2})")
    print(f"  sliding window is {t_brute / t_slide:.1f}x faster")

    print("\nEdge cases")
    try:
        busiest_window([5, 6, 7], k=10)
    except ValueError as e:
        print("  fewer readings than the window ->", e)
    print("  window of exactly the data length ->", busiest_window([5, 6, 7], k=3))


if __name__ == "__main__":
    main()
