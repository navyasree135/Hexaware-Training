"""
main.py - runs all five tasks one after another.
Usage:  python main.py        (run generate_orders.py first if orders.csv is missing)
"""
import os
import subprocess
import sys
import time

import task1_search
import task2_sort
import task3_duplicates
import task4_stack_queue
import task5_refund


def banner(text):
    print("\n" + "=" * 78)
    print(text)
    print("=" * 78)


def main():
    if not os.path.exists("orders.csv"):
        print("orders.csv not found, generating it...")
        subprocess.run([sys.executable, "generate_orders.py"], check=True)

    start = time.perf_counter()
    banner("TASK 1 - Linear search vs binary search")
    task1_search.main()
    banner("TASK 2 - Sorting orders by amount")
    task2_sort.main()
    banner("TASK 3 - Duplicate order detection (hash table)")
    task3_duplicates.main()
    banner("TASK 4 - Stack (undo) and Queue (dispatch line)")
    task4_stack_queue.main()
    banner("TASK 5 - Refund: greedy vs dynamic programming")
    task5_refund.main()
    print(f"\nAll tasks finished in {time.perf_counter() - start:.1f} s")


if __name__ == "__main__":
    main()
