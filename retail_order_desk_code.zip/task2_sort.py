"""
Task 2 - Ranking orders by amount (highest first).
  * Bubble sort  -> O(n^2)
  * Merge sort   -> O(n log n)
  * Built-in sorted() for comparison
Also prints a pass-by-pass trace of bubble sort on a small list for the paper work.
"""
import random
import time

from common import load_orders


def bubble_sort_desc(arr, trace=False, max_passes=None):
    """Bubble sort, biggest value first. Sorts a copy and returns it.
    Each pass pushes the smallest remaining value to the end.
    If trace=True it prints the list after each pass (up to max_passes)."""
    a = list(arr)
    n = len(a)
    for p in range(n - 1):
        swapped = False
        for j in range(n - 1 - p):
            if a[j] < a[j + 1]:              # wrong order for descending -> swap
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if trace:
            print(f"  After pass {p + 1}: {a}")
            if max_passes and p + 1 >= max_passes:
                break
        if not swapped:                      # already sorted, stop early
            break
    return a


def merge_sort_desc(arr):
    """Merge sort, biggest value first. Split in half, sort each half, merge."""
    if len(arr) <= 1:
        return list(arr)
    mid = len(arr) // 2
    left = merge_sort_desc(arr[:mid])
    right = merge_sort_desc(arr[mid:])

    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] >= right[j]:              # >= keeps equal amounts in original order
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def timed(fn, *args):
    start = time.perf_counter()
    result = fn(*args)
    return result, time.perf_counter() - start


def main():
    # ---- paper trace on a small example ----
    sample = [450, 1200, 300, 2500, 850, 150]
    print("Bubble sort trace (descending) on a 6 element list")
    print("  Start:        ", sample)
    bubble_sort_desc(sample, trace=True, max_passes=3)
    print()

    # ---- benchmark on 10,000 real orders ----
    orders = load_orders()[:10_000]
    amounts = [o["amount"] for o in orders]
    print(f"Benchmark on {len(amounts):,} order amounts")

    bub, t_bub = timed(bubble_sort_desc, amounts)
    mer, t_mer = timed(merge_sort_desc, amounts)
    bui, t_bui = timed(lambda x: sorted(x, reverse=True), amounts)

    # make sure all three agree before trusting the timings
    assert bub == mer == bui, "sorting results do not match!"
    print("All three methods give the same ordering: OK\n")

    print(f"{'Method':<22}{'Complexity':<14}{'Time (s)':>10}{'vs bubble':>14}")
    print("-" * 60)
    print(f"{'Bubble sort':<22}{'O(n^2)':<14}{t_bub:>10.4f}{'1.0x':>14}")
    print(f"{'Merge sort':<22}{'O(n log n)':<14}{t_mer:>10.4f}{t_bub / t_mer:>13.1f}x")
    print(f"{'Built-in sorted()':<22}{'O(n log n)':<14}{t_bui:>10.4f}{t_bub / t_bui:>13.1f}x")
    print("-" * 60)
    print(f"sorted() is {t_mer / t_bui:.1f}x faster than my merge sort")

    print("\nTop 5 orders by amount:")
    top = sorted(orders, key=lambda o: o["amount"], reverse=True)[:5]
    for o in top:
        print(f"  order {o['orderId']:>6}  {o['customerId']}  Rs {o['amount']:>10,.2f}")


if __name__ == "__main__":
    main()
