"""common.py - small helper shared by all the task files."""
import csv


def load_orders(path="orders.csv"):
    """Read orders.csv and return a list of dicts.
    orderId is converted to int and amount to float so we can compare them."""
    orders = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            orders.append({
                "orderId": int(row["orderId"]),
                "customerId": row["customerId"],
                "amount": float(row["amount"]),
                "createdAt": row["createdAt"],
            })
    return orders
