"""
Task 1 - Linear search vs binary search on 50,000 orders.
Support agents look up an order by orderId, so we compare two ways of doing it.
"""
import random
import time

from common import load_orders


def linear_search(orders, target_id):
    """Check every order from the start until the id matches.
    Returns (order or None, number of comparisons). Time: O(n)."""
    comparisons = 0
    for order in orders:
        comparisons += 1
        if order["orderId"] == target_id:
            return order, comparisons
    return None, comparisons


def binary_search(orders, target_id):
    """Needs orders sorted by orderId. Look at the middle element and throw
    away the half that cannot contain the id. Time: O(log n)."""
    low, high = 0, len(orders) - 1
    comparisons = 0
    while low <= high:
        mid = (low + high) // 2
        comparisons += 1
        mid_id = orders[mid]["orderId"]
        if mid_id == target_id:
            return orders[mid], comparisons
        elif mid_id < target_id:
            low = mid + 1
        else:
            high = mid - 1
    return None, comparisons


def benchmark(search_fn, orders, targets):
    """Run search_fn for every target. Returns (total seconds, total comparisons)."""
    total_comparisons = 0
    start = time.perf_counter()
    for t in targets:
        _, c = search_fn(orders, t)
        total_comparisons += c
    elapsed = time.perf_counter() - start
    return elapsed, total_comparisons


def main():
    orders = load_orders()
    # binary search only works on sorted data, so sort by orderId first
    orders.sort(key=lambda o: o["orderId"])
    n = len(orders)
    print(f"Loaded {n:,} orders\n")

    # quick correctness check before timing anything
    sample = random.Random(1).choice(orders)
    print("Sanity check, looking for order", sample["orderId"])
    print("  linear :", linear_search(orders, sample["orderId"])[0]["customerId"])
    print("  binary :", binary_search(orders, sample["orderId"])[0]["customerId"])
    print("  missing id 999999 ->", linear_search(orders, 999999)[0],
          binary_search(orders, 999999)[0])
    print()

    rng = random.Random(7)
    LOOKUPS = 1000
    scenarios = [
        ("First order (best case)", [orders[0]["orderId"]] * LOOKUPS),
        ("Last order (worst case)", [orders[-1]["orderId"]] * LOOKUPS),
        ("Missing id", [999999] * LOOKUPS),
        ("1,000 random ids", [rng.randint(1, n) for _ in range(LOOKUPS)]),
    ]

    print(f"Each row = {LOOKUPS} lookups")
    header = (f"{'Scenario':<26}{'Method':<9}{'Total (ms)':>12}"
              f"{'Per lookup (us)':>17}{'Avg comparisons':>17}")
    print(header)
    print("-" * len(header))
    for name, targets in scenarios:
        t_lin, c_lin = benchmark(linear_search, orders, targets)
        t_bin, c_bin = benchmark(binary_search, orders, targets)
        print(f"{name:<26}{'linear':<9}{t_lin * 1000:>12.2f}"
              f"{t_lin / LOOKUPS * 1e6:>17.2f}{c_lin / LOOKUPS:>17.1f}")
        print(f"{'':<26}{'binary':<9}{t_bin * 1000:>12.2f}"
              f"{t_bin / LOOKUPS * 1e6:>17.2f}{c_bin / LOOKUPS:>17.1f}")
        if t_bin > 0:
            ratio = t_lin / t_bin
            if ratio >= 1:
                print(f"{'':<26}-> binary is {ratio:,.1f}x faster")
            else:
                print(f"{'':<26}-> linear is {1 / ratio:,.1f}x faster here")
        print("-" * len(header))


if __name__ == "__main__":
    main()
