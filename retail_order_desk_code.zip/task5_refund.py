"""
Task 5 - Minimum number of notes/coins for a refund.
  * Greedy: always take the biggest denomination that still fits.
  * Dynamic programming: build the answer for every amount from 0 up to the target.
Greedy works for the Indian notes/coins, but fails for some other sets like {1, 3, 4}.
"""


def greedy_change(amount, denominations):
    """Greedy: sort big -> small and take as many of each as possible.
    Returns a list of the coins used. Time: O(k) after sorting, k = number of denominations."""
    used = []
    remaining = amount
    for d in sorted(denominations, reverse=True):
        while remaining >= d:
            used.append(d)
            remaining -= d
    if remaining != 0:
        return None                       # could not make the amount exactly
    return used


def dp_change(amount, denominations):
    """Bottom-up DP.
    dp[a]   = fewest coins needed to make amount a
    pick[a] = the last coin used for that best answer (so we can rebuild the coins)
    Time: O(amount * k)   Space: O(amount)"""
    INF = float("inf")
    dp = [0] + [INF] * amount
    pick = [None] * (amount + 1)

    for a in range(1, amount + 1):
        for c in denominations:
            if c <= a and dp[a - c] + 1 < dp[a]:
                dp[a] = dp[a - c] + 1
                pick[a] = c

    if dp[amount] == INF:
        return None, dp, pick

    coins = []
    a = amount
    while a > 0:
        coins.append(pick[a])
        a -= pick[a]
    return coins, dp, pick


def summary(coins):
    """Turn [500, 500, 100] into '500x2 100x1'."""
    counts = {}
    for c in coins:
        counts[c] = counts.get(c, 0) + 1
    return " ".join(f"{d}x{n}" for d, n in sorted(counts.items(), reverse=True))


def main():
    # ---- part 1: Indian denominations, greedy ----
    indian = [500, 200, 100, 50, 20, 10, 5, 2, 1]
    refund = 3888
    coins = greedy_change(refund, indian)
    print(f"Refund of Rs {refund} using {indian}")
    print(f"  Greedy: {len(coins)} notes/coins -> {summary(coins)}")
    best, _, _ = dp_change(refund, indian)
    print(f"  DP check: {len(best)} notes/coins  (same count, so greedy is fine here)")

    # a few more amounts, comparing greedy and DP
    print("\nGreedy vs DP on the Indian set")
    for amt in [1, 99, 387, 1999, 4750]:
        g = greedy_change(amt, indian)
        d, _, _ = dp_change(amt, indian)
        verdict = "same" if len(g) == len(d) else "DIFFERENT"
        print(f"  Rs {amt:<5} greedy = {len(g):<2} DP = {len(d):<2} {verdict}")

    # ---- part 2: a set where greedy fails ----
    weird = [1, 3, 4]
    target = 6
    print(f"\nDenominations {weird}, amount {target}")
    g = greedy_change(target, weird)
    print(f"  Greedy: {len(g)} coins -> {g}")

    d, dp, pick = dp_change(target, weird)
    print(f"  DP    : {len(d)} coins -> {d}")
    print(f"  Greedy used {len(g) - len(d)} extra coin, so greedy is NOT optimal here.")

    print("\nDP table")
    print(f"  {'amount':<8}{'min coins':<11}{'last coin used'}")
    for a in range(target + 1):
        print(f"  {a:<8}{dp[a]:<11}{pick[a] if pick[a] else '-'}")

    # ---- edge cases ----
    print("\nEdge cases")
    print("  amount 0           ->", dp_change(0, weird)[0])
    print("  amount 7, only [2] ->", dp_change(7, [2])[0], "(cannot be made)")


if __name__ == "__main__":
    main()
