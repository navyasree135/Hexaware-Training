"""
Task 4 - My own Stack (undo last order edit) and my own Queue (dispatch line),
then the same thing again with Python's built-in list and collections.deque.
"""
import time
from collections import deque


class _Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class Stack:
    """LIFO stack built on a singly linked list. The top of the stack is the head."""

    def __init__(self):
        self._top = None
        self._size = 0

    def push(self, value):               # O(1)
        node = _Node(value)
        node.next = self._top
        self._top = node
        self._size += 1

    def pop(self):                       # O(1)
        if self._top is None:
            raise IndexError("pop from empty stack")
        node = self._top
        self._top = node.next
        self._size -= 1
        return node.value

    def peek(self):                      # O(1)
        if self._top is None:
            raise IndexError("peek at empty stack")
        return self._top.value

    def is_empty(self):
        return self._top is None

    def __len__(self):
        return self._size


class Queue:
    """FIFO queue built on a linked list with a head (front) and a tail (back),
    so both enqueue and dequeue are O(1)."""

    def __init__(self):
        self._head = None
        self._tail = None
        self._size = 0

    def enqueue(self, value):            # O(1)
        node = _Node(value)
        if self._tail is None:
            self._head = self._tail = node
        else:
            self._tail.next = node
            self._tail = node
        self._size += 1

    def dequeue(self):                   # O(1)
        if self._head is None:
            raise IndexError("dequeue from empty queue")
        node = self._head
        self._head = node.next
        if self._head is None:           # queue became empty
            self._tail = None
        self._size -= 1
        return node.value

    def front(self):
        if self._head is None:
            raise IndexError("queue is empty")
        return self._head.value

    def is_empty(self):
        return self._head is None

    def __len__(self):
        return self._size


# ---------------------------------------------------------------- demos
def undo_demo(stack):
    """Edit an order three times, saving (field, old value) on the stack each time,
    then undo all three. Works with my Stack or with a plain list."""
    # my Stack has push/pop, a list has append/pop - small wrapper so one demo fits both
    push = stack.push if hasattr(stack, "push") else stack.append

    order = {"orderId": 1001, "amount": 2500.0,
             "address": "Flat 101, Palm Grove, Bengaluru", "status": "Placed"}

    def show(label):
        print(f"  {label:<16}{order['amount']:>7.1f} | {order['status']:<18}| {order['address']}")

    def edit(field, new_value):
        push((field, order[field]))      # remember the old value BEFORE changing it
        order[field] = new_value

    print(f"  {'':<16}{'amount':>7} | {'status':<18}| address")
    show("Start")
    edit("address", "Tower 4, Outer Ring Rd, Bengaluru")
    edit("amount", 2125.0)
    edit("status", "Priority Dispatch")
    show("After 3 edits")

    while len(stack) > 0:
        field, old_value = stack.pop()
        order[field] = old_value
        show(f"Undo {field}")
    return order


def dispatch_demo(queue):
    """Orders join the line and are packed in arrival order."""
    enqueue = queue.enqueue if hasattr(queue, "enqueue") else queue.append
    dequeue = queue.dequeue if hasattr(queue, "dequeue") else queue.popleft
    for oid, city in [(5001, "Mumbai"), (5002, "Delhi"), (5003, "Hyderabad"), (5004, "Chennai")]:
        enqueue((oid, city))
        print(f"  order {oid} ({city}) joined the line, length = {len(queue)}")
    while len(queue) > 0:
        oid, city = dequeue()
        print(f"  packed order {oid} for {city}, left in line = {len(queue)}")


# ---------------------------------------------------------------- benchmarks
def time_stack(make, push_name, N):
    s = make()
    push = getattr(s, push_name)
    start = time.perf_counter()
    for i in range(N):
        push(i)
    for _ in range(N):
        s.pop()
    return time.perf_counter() - start


def time_queue(make, add_name, remove_name, N):
    q = make()
    add = getattr(q, add_name)
    remove = getattr(q, remove_name)
    start = time.perf_counter()
    for i in range(N):
        add(i)
    for _ in range(N):
        remove() if remove_name != "pop" else remove(0)
    return time.perf_counter() - start


def main():
    print("=== A. Undo with my own Stack ===")
    undo_demo(Stack())
    print("\n=== A2. Same undo with a built-in list ===")
    undo_demo([])

    print("\n=== B. Dispatch line with my own Queue ===")
    dispatch_demo(Queue())
    print("\n=== B2. Same dispatch line with collections.deque ===")
    dispatch_demo(deque())

    N = 50_000
    print(f"\n=== C. Timing, {N:,} pushes + {N:,} pops (or enqueues + dequeues) ===")
    t_my_stack = time_stack(Stack, "push", N)
    t_list_stack = time_stack(list, "append", N)
    print(f"{'Stack':<34}{'Time (s)':>10}")
    print(f"{'my Stack (linked list)':<34}{t_my_stack:>10.4f}")
    print(f"{'built-in list (append/pop)':<34}{t_list_stack:>10.4f}")

    t_my_q = time_queue(Queue, "enqueue", "dequeue", N)
    t_deque = time_queue(deque, "append", "popleft", N)
    t_list_q = time_queue(list, "append", "pop", N)      # list.pop(0)
    print(f"\n{'Queue':<34}{'Time (s)':>10}{'vs list.pop(0)':>16}")
    print(f"{'list (append / pop(0))':<34}{t_list_q:>10.4f}{'1.0x':>16}")
    print(f"{'my Queue (linked list)':<34}{t_my_q:>10.4f}{t_list_q / t_my_q:>15.1f}x")
    print(f"{'collections.deque':<34}{t_deque:>10.4f}{t_list_q / t_deque:>15.1f}x")


if __name__ == "__main__":
    main()
