"""
generate_orders.py
Creates orders.csv with 50,000 orders (orderId, customerId, amount, createdAt).
About 50 orders are deliberate duplicates (same customer + same amount, placed
within the same minute) so that Task 3 has something to find.
"""
import csv
import random
from datetime import datetime, timedelta

random.seed(42)          # fixed seed so the output is the same every run

TOTAL_ORDERS = 50_000
NUM_DUPLICATES = 50
NUM_CUSTOMERS = 8_000

start = datetime(2026, 10, 25, 0, 0, 0)

rows = []
current_time = start
for order_id in range(1, TOTAL_ORDERS + 1):
    # orders arrive roughly 1.7 seconds apart, so 50,000 orders is about one day
    current_time += timedelta(seconds=random.randint(1, 3))
    customer_id = f"CUST-{random.randint(1, NUM_CUSTOMERS):04d}"
    amount = round(random.lognormvariate(6.5, 1.0), 2)   # mostly small, few big
    rows.append([order_id, customer_id, amount, current_time])

# Plant duplicates: pick random orders and make the *next* order a copy of them
# (same customer, same amount, a few seconds later, same minute)
planted = 0
tries = 0
while planted < NUM_DUPLICATES and tries < 10_000:
    tries += 1
    i = random.randint(0, TOTAL_ORDERS - 2)
    original = rows[i]
    nxt = rows[i + 1]
    # only works if the next order is still in the same minute
    if nxt[3].replace(second=0) != original[3].replace(second=0):
        continue
    if nxt[1] == original[1] and nxt[2] == original[2]:
        continue                       # already a duplicate
    nxt[1] = original[1]
    nxt[2] = original[2]
    planted += 1

with open("orders.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["orderId", "customerId", "amount", "createdAt"])
    for r in rows:
        writer.writerow([r[0], r[1], r[2], r[3].strftime("%Y-%m-%d %H:%M:%S")])

print(f"Wrote {TOTAL_ORDERS} orders to orders.csv ({planted} duplicates planted)")
