"""make_chart.py - bar charts of the timings (search, sort, queue). Saves benchmarks.png"""
import random
import time
from collections import deque

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import load_orders
from task1_search import linear_search, binary_search, benchmark
from task2_sort import bubble_sort_desc, merge_sort_desc
from task4_stack_queue import Queue

orders = load_orders()
n = len(orders)

# ---- search: 1,000 lookups each ----
last_ids = [orders[-1]["orderId"]] * 1000
rand_ids = [random.Random(7).randint(1, n) for _ in range(1000)]
search = {}
for name, ids in [("Last order", last_ids), ("Random ids", rand_ids)]:
    search[name] = (benchmark(linear_search, orders, ids)[0] * 1000,
                    benchmark(binary_search, orders, ids)[0] * 1000)

# ---- sort: 10,000 amounts ----
amounts = [o["amount"] for o in orders[:10_000]]
t = time.perf_counter(); bubble_sort_desc(amounts); t_bub = time.perf_counter() - t
t = time.perf_counter(); merge_sort_desc(amounts); t_mer = time.perf_counter() - t
t = time.perf_counter(); sorted(amounts, reverse=True); t_bui = time.perf_counter() - t

# ---- queue: 50,000 enqueue + dequeue ----
N = 50_000
def run_queue(q, add, remove, zero=False):
    a, r = getattr(q, add), getattr(q, remove)
    t0 = time.perf_counter()
    for i in range(N):
        a(i)
    for _ in range(N):
        r(0) if zero else r()
    return time.perf_counter() - t0
q_list = run_queue([], "append", "pop", zero=True)
q_mine = run_queue(Queue(), "enqueue", "dequeue")
q_deque = run_queue(deque(), "append", "popleft")

fig, ax = plt.subplots(1, 3, figsize=(13, 4))
BLUE, ORANGE, GREY = "#2f6fb0", "#e08a2e", "#8a8f98"

# panel 1 - search (log scale because the gap is huge)
names = list(search)
x = range(len(names))
ax[0].bar([i - 0.2 for i in x], [search[k][0] for k in names], 0.4, label="Linear", color=ORANGE)
ax[0].bar([i + 0.2 for i in x], [search[k][1] for k in names], 0.4, label="Binary", color=BLUE)
ax[0].set_xticks(list(x)); ax[0].set_xticklabels(names)
ax[0].set_yscale("log"); ax[0].set_ylabel("ms for 1,000 lookups (log scale)")
ax[0].set_title("Search, 50,000 orders"); ax[0].legend()

# panel 2 - sorting
labels = ["Bubble", "Merge", "sorted()"]
vals = [t_bub, t_mer, t_bui]
ax[1].bar(labels, vals, color=[ORANGE, BLUE, GREY])
ax[1].set_yscale("log"); ax[1].set_ylabel("seconds (log scale)")
ax[1].set_title("Sorting, 10,000 amounts")
for i, v in enumerate(vals):
    ax[1].text(i, v, f"{v:.4f}s", ha="center", va="bottom", fontsize=8)

# panel 3 - queue
labels = ["list.pop(0)", "my Queue", "deque"]
vals = [q_list, q_mine, q_deque]
ax[2].bar(labels, vals, color=[ORANGE, BLUE, GREY])
ax[2].set_yscale("log"); ax[2].set_ylabel("seconds (log scale)")
ax[2].set_title("Queue, 50,000 enqueue + dequeue")
for i, v in enumerate(vals):
    ax[2].text(i, v, f"{v:.4f}s", ha="center", va="bottom", fontsize=8)

for a in ax:
    a.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
plt.savefig("benchmarks.png", dpi=170)
print("saved benchmarks.png")
