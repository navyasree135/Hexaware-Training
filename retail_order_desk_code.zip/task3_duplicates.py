"""
Task 3 - Flag duplicate submissions before payment is captured.
Two orders are duplicates if they have the same customerId, the same amount,
and were created in the same minute. A dictionary (hash table) lets us check
this in one pass over the data.
"""
import time

from common import load_orders


def find_duplicates(orders):
    """Return a list of (original_order, duplicate_order) pairs.
    Key = (customerId, amount, createdAt cut down to the minute).
    Time: O(n)   Space: O(n)"""
    seen = {}            # key -> first order we saw with that key
    duplicates = []
    for order in orders:
        minute = order["createdAt"][:16]          # "2026-10-25 10:01"
        key = (order["customerId"], order["amount"], minute)
        if key in seen:
            duplicates.append((seen[key], order))
        else:
            seen[key] = order
    return duplicates


def find_duplicates_bruteforce(orders):
    """Compare every pair of orders. Only here to show why we need the hash
    table, it is O(n^2). Only run on a small slice."""
    found = 0
    for i in range(len(orders)):
        for j in range(i + 1, len(orders)):
            a, b = orders[i], orders[j]
            if (a["customerId"] == b["customerId"] and a["amount"] == b["amount"]
                    and a["createdAt"][:16] == b["createdAt"][:16]):
                found += 1
    return found


def main():
    orders = load_orders()
    print(f"Checking {len(orders):,} orders for duplicates...\n")

    start = time.perf_counter()
    dups = find_duplicates(orders)
    hash_time = time.perf_counter() - start

    print(f"Duplicates found : {len(dups)}")
    print(f"Time taken       : {hash_time * 1000:.2f} ms\n")

    print("First 10 duplicates:")
    print(f"{'Dup order':>10} {'Original':>9}  {'Customer':<10}{'Amount':>10}  "
          f"{'Original time':<20}{'Duplicate time'}")
    for orig, dup in dups[:10]:
        print(f"{dup['orderId']:>10} {orig['orderId']:>9}  {dup['customerId']:<10}"
              f"{dup['amount']:>10.2f}  {orig['createdAt']:<20}{dup['createdAt']}")

    # small comparison: hash table vs checking every pair, on the first 6,000 orders
    small = orders[:6000]
    start = time.perf_counter()
    a = len(find_duplicates(small))
    t_hash = time.perf_counter() - start
    start = time.perf_counter()
    b = find_duplicates_bruteforce(small)
    t_brute = time.perf_counter() - start
    print(f"\nOn the first {len(small):,} orders:")
    print(f"  hash table : {a} duplicates in {t_hash * 1000:.2f} ms")
    print(f"  all pairs  : {b} duplicates in {t_brute * 1000:.2f} ms")
    print(f"  hash table is about {t_brute / t_hash:,.0f}x faster")
    print("\nComplexity: time O(n), space O(n)")


if __name__ == "__main__":
    main()
